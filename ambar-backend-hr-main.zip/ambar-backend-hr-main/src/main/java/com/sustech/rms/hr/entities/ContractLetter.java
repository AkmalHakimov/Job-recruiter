package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.JobReqApplTypeRefEntity;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "hgz_contract_letter")
public class ContractLetter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_contract_letter_pk_id")
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "contract_letter_hgz_application_pk_id", unique = true)
    private Application application;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "hgz_job_req_appl_type_ref_id", nullable = false)
    private JobReqApplTypeRefEntity contractType;
    @Column(nullable = false)
    private LocalDate contractCommencementDate;
    private Long hoursOfOperation;
    private String pay;
    private String location;
    @Column(nullable = false)
    private String governingLaw;
    private String industrialInstrument;
    private LocalDate dateOfAgreement;
    private String services;
    private String noticePeriod;
    private String name;
    private Long numberOfDays;
    private String liabilityRequirement;
    private String fee;
    @ManyToMany
    @JoinTable(
            name = "hgz_contract_letter_employee_onboarding_documents",
            joinColumns = @JoinColumn(name = "hgz_contract_letter_pk_id",
                    referencedColumnName = "hgz_contract_letter_pk_id"),
            inverseJoinColumns = @JoinColumn(name = "hgz_employee_onboarding_document_pk_id",
                    referencedColumnName = "hgz_employee_onboarding_document_pk_id"))
    private List<EmployeeOnboardingDocument> employeeOnboardingDocuments;
    @Column(nullable = false)
    @Builder.Default
    private Boolean sent = false;
}
