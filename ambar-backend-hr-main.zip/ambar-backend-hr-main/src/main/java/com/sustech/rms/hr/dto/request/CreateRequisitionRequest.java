package com.sustech.rms.hr.dto.request;

import lombok.Data;

import java.sql.Timestamp;
import java.time.LocalDate;

@Data
public class CreateRequisitionRequest {
    private Timestamp requestDate;
    private Timestamp startDate;
    private Timestamp endDate;
    private Long jobSkillTypeId;
    private Long orgDepartmentId;
    private Long cityId;
    private String priority;
    private String status;
    private String progress;
}
