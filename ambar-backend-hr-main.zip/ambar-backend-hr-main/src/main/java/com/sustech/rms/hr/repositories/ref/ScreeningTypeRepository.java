package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.ScreeningType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScreeningTypeRepository extends JpaRepository<ScreeningType,Long> {
}
