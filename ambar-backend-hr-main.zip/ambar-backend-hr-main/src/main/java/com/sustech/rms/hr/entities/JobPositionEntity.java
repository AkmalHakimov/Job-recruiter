package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.constants.PriorityEnum;
import com.sustech.rms.hr.entities.ref.*;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_postion")
@NoArgsConstructor
@AllArgsConstructor
public class JobPositionEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_POSN_PK_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_ORG_DEPARTMENT")
    private OrgDepartmentRefEntity orgDepartment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_CITY")
    private CityRefEntity city;

    @Column(name = "C_PRIORITY")
    private String priority;

    @Column(name = "V_STATUS")
    private String status;

    @Column(name = "V_PROGRESS")
    private String progress;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_INDSTRY_DISCPLN_REF_PK_ID")
    private IndustryDisciplineRefEntity industryDiscipline;

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "N_JOB_DESGNTN_TYP_REF_PK_ID")
//    private JobDesignationTypeRefEntity jobDesignationType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_TYP_REF_PK_ID")
    private JobPositionTypeRefEntity jobPositionType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_INDSTRY_REF_PK_ID")
    private IndustryRefEntity industry;

    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "V_JOB_POSN_DESC")
    private String description;

    @Column(name = "T_JOB_REQ_CRT_TMSP")
    private Timestamp jobReqCreatedAt;

    @Column(name = "N_TRGT_OPEN_CNT")
    private Integer targetOpen;

    @Column(name = "V_STAT_CD")
    private String statusCode;

    @Column(name = "N_MIN_REQ_EXPR_YR_NUM")
    private Integer minReqExperience;

    @Column(name = "N_MAX_REQ_EXPR_YR_NUM")
    private Integer maxReqExperience;

    @Column(name = "N_FULFLMNT_CNT")
    private Integer fulfilment;

    @Column(name = "V_PRIORTY_IND")
    private String priorityIndex;

    @Column(name = "V_JOB_POSN_NOTE_TXT")
    private String note;

    @CreationTimestamp
    @Column(name = "T_REQUEST_DATE")
    private Timestamp requestDate;

    @Column(name = "T_START_DATE")
    private Timestamp startDate;

    @Column(name = "T_END_DATE")
    private Timestamp endDate;

    @Column(name = "D_JOB_TRGT_FULFLMNT_DT")
    private LocalDate targetDate;

    public JobPositionEntity(IndustryDisciplineRefEntity industryDiscipline,
                             JobPositionTypeRefEntity jobPositionType,
                             OrgDepartmentRefEntity department,
                             int targetOpen, int minReqExperience,
                             int maxReqExperience, String description,
                             LocalDate targetDate, Timestamp startDate, Timestamp endDate) {
        this.industryDiscipline = industryDiscipline;
        this.jobPositionType = jobPositionType;
        this.targetOpen = targetOpen;
        this.minReqExperience = minReqExperience;
        this.maxReqExperience = maxReqExperience;
        this.orgDepartment = department;
        this.description = description;
        this.targetDate = targetDate;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public JobPositionEntity jobPositionChanger(IndustryDisciplineRefEntity industryDiscipline,
                                                JobPositionTypeRefEntity jobPositionType,
                                                OrgDepartmentRefEntity department,
                                                int targetOpen, int minReqExperience,
                                                int maxReqExperience, String description,
                                                LocalDate targetDate, Timestamp startDate,
                                                Timestamp endDate, PriorityEnum priority,
                                                Timestamp requestDate) {
        this.industryDiscipline = industryDiscipline;
        this.jobPositionType = jobPositionType;
        this.targetOpen = targetOpen;
        this.minReqExperience = minReqExperience;
        this.maxReqExperience = maxReqExperience;
        this.orgDepartment = department;
        this.description = description;
        this.targetDate = targetDate;
        this.startDate = startDate;
        this.endDate = endDate;
        this.priority = String.valueOf(priority);
        this.requestDate = requestDate;
        return this;
    }

    public JobPositionEntity(OrgDepartmentRefEntity orgDepartment, CityRefEntity city, String priority, String status, String progress, IndustryDisciplineRefEntity industryDiscipline, JobPositionTypeRefEntity jobPositionType, IndustryRefEntity industry, String systemCode, String description, Timestamp jobReqCreatedAt, Integer targetOpen, String statusCode, Integer minReqExperience, Integer maxReqExperience, Integer fulfilment, String priorityIndex, String note, Timestamp requestDate, Timestamp startDate, Timestamp endDate, LocalDate targetDate) {
        this.orgDepartment = orgDepartment;
        this.city = city;
        this.priority = priority;
        this.status = status;
        this.progress = progress;
        this.industryDiscipline = industryDiscipline;
        this.jobPositionType = jobPositionType;
        this.industry = industry;
        this.systemCode = systemCode;
        this.description = description;
        this.jobReqCreatedAt = jobReqCreatedAt;
        this.targetOpen = targetOpen;
        this.statusCode = statusCode;
        this.minReqExperience = minReqExperience;
        this.maxReqExperience = maxReqExperience;
        this.fulfilment = fulfilment;
        this.priorityIndex = priorityIndex;
        this.note = note;
        this.requestDate = requestDate;
        this.startDate = startDate;
        this.endDate = endDate;
        this.targetDate = targetDate;
    }

    @Override
    public JobPositionEntity clone() {
        try {
            JobPositionEntity clone = (JobPositionEntity) super.clone();
            clone.setCreatedAt(null);
            clone.setUpdatedAt(null);
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
