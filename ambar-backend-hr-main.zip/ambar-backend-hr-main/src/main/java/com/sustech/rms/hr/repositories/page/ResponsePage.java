package com.sustech.rms.hr.repositories.page;

import java.util.List;

public interface ResponsePage<T> {

  public List<T> getElements();

  public RequestPage getRequestPage();

  public long getTotalElements();

}
