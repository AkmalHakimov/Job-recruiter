package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class ComplianceUpdateReq {
    @NotNull
    private Long jobPositionId;
    @NotEmpty
    private String document;
    private String notes;
    @NotEmpty
    private String source;
}
