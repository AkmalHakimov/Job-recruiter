package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_certificate_review",
        uniqueConstraints = @UniqueConstraint(columnNames = {"certificate_id", "application_id"}))
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class CertificationReview extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_certificate_review_pk_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "certificate_id")
    private JobRequisitionCertificateSpecEntity certificate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    private Application application;

    private Byte mark;//100 50 0. default null
}
