package com.sustech.rms.hr.repositories;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.repositories.page.RequestPage;
import com.sustech.rms.hr.repositories.page.ResponsePage;
import com.sustech.rms.hr.repositories.page.ResponsePageImpl;
import com.sustech.rms.hr.repositories.predicate.Contract;
import com.sustech.rms.hr.repositories.predicate.ContractHandler;
import com.sustech.rms.hr.repositories.predicate.PredicateSet;
import org.springframework.beans.factory.annotation.Autowired;

import com.sustech.rms.hr.constants.JobRequisitionEnums.ColumnCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.NumberOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.StringOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.TimestampOperatorCode;
import com.sustech.rms.hr.dto.request.SearchCriteriaRequest;

public class JobRequisitionsCompositeRepositoryImpl implements JobRequisitionsCompositeRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ContractHandler contractHandler;

    @Override
    public ResponsePage<JobPositionEntity> findJobRequisitions(RequestPage requestPage) {
        return findJobRequisitions(new ArrayList<SearchCriteriaRequest>(), requestPage);
    }

    @Override
    public ResponsePage<JobPositionEntity> findJobRequisitions(
            String searchValue, RequestPage requestPage) {

        ColumnCode[] codes = ColumnCode.values();
        List<SearchCriteriaRequest> scrl = new ArrayList<>();

        for (int i = 0; i < codes.length; i++) {
            String operatorCode = null;

            switch (codes[i]) {
                case JOBREQID:
                    operatorCode = NumberOperatorCode.NUM_EQUAL.name();
                case REQUESTDATE:
                case STARTDATE:
                case ENDDATE:
                    operatorCode = TimestampOperatorCode.TIME_EQUAL.name();
                case PRIORITY:
                case STATUS:
                case PROGRESS:
                    operatorCode = StringOperatorCode.STR_EQUAL.name();
                case JOBSKILLTYPEDESC:
                case ORGDEPTNAME:
                case CITYNAME:
                case CITYCOUNTRYNAME:
                default:
                    operatorCode = StringOperatorCode.STR_CONTAIN.name();
            }

            SearchCriteriaRequest scr = new SearchCriteriaRequest();
            scr.setColumnCode(codes[i].name());
            scr.setOperatorCode(operatorCode);
            scr.setSearchValue(searchValue);
            scrl.add(scr);
        }

        return selectJobRequisitions(scrl, requestPage, true);
    }

    @Override
    public ResponsePage<JobPositionEntity> findJobRequisitions(
            List<SearchCriteriaRequest> searchCriteriaList, RequestPage requestPage) {

        return selectJobRequisitions(
                searchCriteriaList, requestPage, false);
    }

    private Contract createPredicateContract(
            Root<JobPositionEntity> root,
            List<SearchCriteriaRequest> scrl) {

        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        Contract contract = contractHandler.newContract(root, builder);
        Iterator<SearchCriteriaRequest> scrlIter = scrl.iterator();

        while (scrlIter.hasNext()) {
            SearchCriteriaRequest scr = scrlIter.next();
            String columnCode = scr.getColumnCode();
            String operatorCode = scr.getOperatorCode();
            Object searchValue = scr.getSearchValue();

            contractHandler.addPredicate(
                    contract,
                    columnCode,
                    operatorCode,
                    searchValue);
        }

        return contract;
    }

    private Predicate buildBasePredicate(Contract contract, boolean isBlindQuery) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        List<Predicate> secondaryPredicateList = new ArrayList<Predicate>();
        List<PredicateSet> tertiaryPredicateSetList = contract.getPredicateSetList();
        Iterator<PredicateSet> pslIter = tertiaryPredicateSetList.iterator();

        while (pslIter.hasNext()) {
            PredicateSet ps = pslIter.next();
            Predicate secondaryPredicate = builder.or(ps.getPredicateArray());
            secondaryPredicateList.add(secondaryPredicate);
        }

        Predicate[] predArr = new Predicate[secondaryPredicateList.size()];

        Predicate basePredicate = (isBlindQuery)
                ? builder.or(secondaryPredicateList.toArray(predArr))
                : builder.and(secondaryPredicateList.toArray(predArr));

        return basePredicate;
    }

    private ResponsePage<JobPositionEntity> selectJobRequisitions(
            List<SearchCriteriaRequest> searchCriteriaList,
            RequestPage requestPage,
            boolean isBlindQuery) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        // Selecting the job requisitions based on the predicate.
        CriteriaQuery<JobPositionEntity> selectQuery = builder.createQuery(JobPositionEntity.class);
        Root<JobPositionEntity> root = selectQuery.from(JobPositionEntity.class);
        TypedQuery<JobPositionEntity> tSelectQuery = null;
        List<JobPositionEntity> result = null;

        Contract contract = createPredicateContract(root, searchCriteriaList);
        Predicate basePredicate = buildBasePredicate(contract, isBlindQuery);
        Order order = builder.desc(root.get("id"));

        selectQuery.select(root).where(basePredicate).orderBy(order);
        tSelectQuery = entityManager.createQuery(selectQuery);
        tSelectQuery.setFirstResult(requestPage.getStartingIndex());
        tSelectQuery.setMaxResults(requestPage.getPageLimit());
        result = tSelectQuery.getResultList();

        // Counting the job requistions based on the predicate.
        CriteriaQuery<Long> countQuery = builder.createQuery(Long.class);
        Root<JobPositionEntity> countRoot = countQuery.from(JobPositionEntity.class);
        TypedQuery<Long> tCountQuery = null;
        Long total = null;

        countQuery.select(builder.count(countRoot)).where(basePredicate);
        tCountQuery = entityManager.createQuery(countQuery);
        total = tCountQuery.getSingleResult();

        return new ResponsePageImpl<JobPositionEntity>(requestPage, result, total);
    }
}
