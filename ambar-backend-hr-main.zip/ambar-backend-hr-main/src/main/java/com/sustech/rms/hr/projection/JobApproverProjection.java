package com.sustech.rms.hr.projection;

public interface JobApproverProjection {
    Long getId();

    String getFullName();

    String getEmail();
}
