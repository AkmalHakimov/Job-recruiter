package com.sustech.rms.hr.projection;

public interface JobReqTemProjection {

    Long getId();

    String getLabel();
}
