package com.sustech.rms.hr.entities.template;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@MappedSuperclass
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public abstract class AbstractEntity {
    @CreationTimestamp
    @Column(updatable = false,name = "T_CRT_TMSP")
    private Timestamp createdAt;

    @UpdateTimestamp
    @Column(name = "T_UPDT_TMSP")
    private Timestamp updatedAt;

    @Column(name = "V_CRT_USER_ID")
    private String createdBy;

    @Column(name = "V_UPDT_USER_ID")
    private String updatedBy;

}
