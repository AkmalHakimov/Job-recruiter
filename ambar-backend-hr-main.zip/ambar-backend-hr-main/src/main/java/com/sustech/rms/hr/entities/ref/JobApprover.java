package com.sustech.rms.hr.entities.ref;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "hgz_approver_user_ref")
@NoArgsConstructor
public class JobApprover {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_APPROVER_REF_PK_ID")
    private Long id;

    @Column(name = "APR_FULLNAME")
    private String fullName;

    @Column(name = "APR_EMAIL", unique = true)
    private String email;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "hgz_approver_user_org_department_ref",
            joinColumns = @JoinColumn(name = "N_APPROVER_REF_PK_ID",
                    referencedColumnName = "N_APPROVER_REF_PK_ID"),
            inverseJoinColumns = @JoinColumn(name = "N_ORG_DEPT_REF_PK_ID",
                    referencedColumnName = "N_ORG_DEPT_REF_PK_ID"))
    private List<OrgDepartmentRefEntity> departmentRef;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "hgz_approver_user_job_designation_type_ref",
            joinColumns = @JoinColumn(name = "N_APPROVER_REF_PK_ID",
                    referencedColumnName = "N_APPROVER_REF_PK_ID"),
            inverseJoinColumns = @JoinColumn(name = "N_JOB_DESGNTN_TYP_REF_PK_ID",
                    referencedColumnName = "N_JOB_DESGNTN_TYP_REF_PK_ID"))
    private List<JobDesignationTypeRefEntity> designationTypeRef;

    public JobApprover(String fullName, String email, List<OrgDepartmentRefEntity> departmentRef, List<JobDesignationTypeRefEntity> designationTypeRef) {
        this.fullName = fullName;
        this.email = email;
        this.departmentRef = departmentRef;
        this.designationTypeRef = designationTypeRef;
    }
}
