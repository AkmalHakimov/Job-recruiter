package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.constants.ContractTypeEnum;
import com.sustech.rms.hr.entities.ref.JobReqApplTypeRefEntity;
import com.sustech.rms.hr.projection.JobQualProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ApplTypeRefRepository extends JpaRepository<JobReqApplTypeRefEntity,Long> {

    List<JobQualProjection> findAllByOrderById();
    Optional<JobReqApplTypeRefEntity> findByDescription(ContractTypeEnum contractTypeEnum);
}
