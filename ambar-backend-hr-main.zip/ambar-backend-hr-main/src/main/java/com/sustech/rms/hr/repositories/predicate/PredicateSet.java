package com.sustech.rms.hr.repositories.predicate;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;

public interface PredicateSet {

  public boolean addPredicate(CriteriaBuilder builder, String operatorCode, Object value);

  public List<Predicate> getPredicates();

  public Predicate[] getPredicateArray();

  public String getColumnCode();

  public Path<?> getPath();

}
