package com.sustech.rms.hr.projection;

public interface CityProjection {
    Long getId();

    String getName();
}
