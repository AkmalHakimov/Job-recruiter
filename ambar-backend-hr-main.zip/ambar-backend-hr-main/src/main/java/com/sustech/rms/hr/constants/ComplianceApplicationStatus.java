package com.sustech.rms.hr.constants;

public enum ComplianceApplicationStatus {
    PENDING,
    SUBMITTED,
    APPROVED,
    REJECTED
}
