package com.sustech.rms.hr.entities.ref;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "hgz_dmgr_country_ref")
public class CountryRefEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_DMGR_CNTRY_REF_PK_ID")
  private Long id;

  @Column(name = "V_COUNTRY_CODE")
  private String code;

  @Column(name = "V_COUNTRY_NAME")
  private String name;

}
