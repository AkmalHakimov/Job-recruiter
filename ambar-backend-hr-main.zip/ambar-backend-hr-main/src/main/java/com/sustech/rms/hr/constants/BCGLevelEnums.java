package com.sustech.rms.hr.constants;

public enum BCGLevelEnums {

    HIGH,

    MEDIUM,

    LOW


}
