package com.sustech.rms.hr.projection;

public interface DepartmentRefProjection {
    Long getId();
    String getName();
    String getCode();
}
