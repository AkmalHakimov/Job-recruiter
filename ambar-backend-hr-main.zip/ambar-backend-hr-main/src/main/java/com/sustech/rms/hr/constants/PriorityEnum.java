package com.sustech.rms.hr.constants;

public enum PriorityEnum {
    HIGH,
    NORMAL,
    LOW
}
