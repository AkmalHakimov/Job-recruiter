package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomFinancialReview {
    Long getId();

    @Value("#{target.financial?.compositionMinRate}")
    String getMinSalary();

    @Value("#{target.financial?.compositionMaxRate}")
    String getMaxSalary();

    @Value("#{target.financial?.jobReqApplTypeRef?.description}")
    String getContractType();

    Byte getMark();
}
