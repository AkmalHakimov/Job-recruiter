package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobDesignationTypeRefEntity;
import com.sustech.rms.hr.projection.JobQualProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobDesignationRefRepository extends JpaRepository<JobDesignationTypeRefEntity,Long> {

    List<JobQualProjection> findAllByOrderById();
}
