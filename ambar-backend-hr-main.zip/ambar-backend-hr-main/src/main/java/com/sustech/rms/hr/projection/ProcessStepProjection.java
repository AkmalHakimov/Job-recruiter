package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

import java.util.Collections;
import java.util.List;

public interface ProcessStepProjection {
    @Value("#{target.screeningType.id}")
    Long getScreeningTypeId();

    @Value("#{target.screeningType.name}")
    String getScreeningTypeName();

    default List<Object> getInterviewUsers() {
        return Collections.emptyList();
    }

    default String getStatus() {
        return null;
    }

    default Object getCityRef() {
        return null;
    }
}
