package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.constants.EmailTemplateTypeEnum;
import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_email_template")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmailTemplate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_email_template_id")
    private Long id;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EmailTemplateTypeEnum emailType;
    private String emailSubject;
    private String emailBody;
}
