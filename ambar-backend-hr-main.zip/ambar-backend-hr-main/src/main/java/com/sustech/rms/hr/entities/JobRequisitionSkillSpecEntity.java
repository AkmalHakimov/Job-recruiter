package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.JobSkillRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_req_skill_spec")
@NoArgsConstructor
public class JobRequisitionSkillSpecEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_REQ_SKILL_SPEC_PK_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    private JobPositionEntity jobPosition;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_SKILL_REF_PK_ID")
    private JobSkillRefEntity jobSkillRef;


    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "N_EXPR_YR_NUM")
    private float experience;

    @Column(name = "V_MAND_SKILL_IND")
    private Boolean mandatory;

    @Column(name = "D_WGHT_NUM")
    private float weight;


    @Column(name = "V_JOB_REQ_SKILL_NOTE_TXT")
    private String note;

    public JobRequisitionSkillSpecEntity(JobPositionEntity jobPosition, JobSkillRefEntity jobSkillRef, float experience, Boolean mandatory, float weight, String note) {
        this.jobPosition = jobPosition;
        this.jobSkillRef = jobSkillRef;
        this.experience = experience;
        this.mandatory = mandatory;
        this.weight = weight;
        this.note = note;
    }

    public JobRequisitionSkillSpecEntity setNewValues(JobPositionEntity jobPosition) {
        this.id = null;
        this.jobPosition = jobPosition;
        return this;
    }

    @Override
    public JobRequisitionSkillSpecEntity clone() {
        try {
            JobRequisitionSkillSpecEntity clone = (JobRequisitionSkillSpecEntity) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
