package com.sustech.rms.hr.constants;

public class JobRequisitionEnums {

    /**
     * Codes that refers to the columns during advance search function.
     */
    public static enum InterviewColumnCode {
        //interview columns
        INTERVIEWAPPLICANTNAME,
        INTERVIEWAPPLICANTSTATUS,
        INTERVIEWSTEPID,
        INTERVIEWSCHEDULED,
        INTERVIEWSTATUS
    }
    public static enum ColumnCode {
        ID,
        JOBREQID,
        REQUESTDATE,
        STARTDATE,
        ENDDATE,
        JOBPOSITIONTYPE,
        ORGDEPARTMENT,
        CITY,
        PRIORITY,
        STATUS,
        PROGRESS,
        JOBSKILLTYPEDESC,
        ORGDEPTNAME,
        CITYNAME,
        CITYCOUNTRYNAME,

        //Application columns
        APPLICANTID,
        REQUISITIONID,
        APPLICANTNAME,
        APPLICANTEMAIL,
        APPLICANTCELL,
        PROFILESCORE,
        REVIEWSCORE,
        MISSINGITEMS,
        CURRENTSALARY,
        EXPECTEDSALARY,
        TOTALEXPERIENCE,

    }

    /**
     * Codes that refers to the operations of columns with numeric values.
     */
    public static enum NumberOperatorCode {
        NUM_EQUAL,
        NUM_NOT_EQUAL,
        NUM_GREATER,
        NUM_GREATER_EQUAL,
        NUM_LESSER,
        NUM_LESSER_EQUAL
    }

    /**
     * Codes that refers to the operations of columns with predefined values.
     */
    public static enum SelectOperatorCode {
        SEL_EQUAL,
        SEL_NOT_EQUAL
    }

    /**
     * Codes that refers to the operations of columns with text values.
     */
    public static enum StringOperatorCode {
        STR_EQUAL,
        STR_NOT_EQUAL,
        STR_CONTAIN,
        STR_NOT_CONTAIN
    }

    /**
     * Codes that refers to the operations of columns with timestamp values.
     */
    public static enum TimestampOperatorCode {
        TIME_EQUAL,
        TIME_NOT_EQUAL,
        TIME_BEFORE,
        TIME_AFTER
    }
}
