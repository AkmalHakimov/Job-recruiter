package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.PriorityEnum;
import lombok.Data;

import java.time.LocalDate;

@Data
public class PositionSummaryReq {
    private String hiringManager;
    private String hrManager;
    private LocalDate targetDate;
    private Integer targetOpen;
    private Long jobPositionId;
    private Long departmentId;
    private PriorityEnum priority;
}
