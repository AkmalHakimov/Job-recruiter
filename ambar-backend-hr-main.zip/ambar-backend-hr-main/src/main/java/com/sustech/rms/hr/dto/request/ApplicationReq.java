package com.sustech.rms.hr.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class ApplicationReq {
    private Long requisitionId;
    private Long jobPositionId;
    private Long applicantId;
    @NotNull
    private String firstName;
    private String middleName = "";
    private String surName = "";
    @NotNull
    private String title;
    @NotNull
    @Email
    private String email;
    private String mobile = "";
    private String phone = "";
    private byte totalExperience;
    private long currentSalary;
    private long expectedSalary;
    @NotNull
    private Long resumeId;
    private String status;
}
