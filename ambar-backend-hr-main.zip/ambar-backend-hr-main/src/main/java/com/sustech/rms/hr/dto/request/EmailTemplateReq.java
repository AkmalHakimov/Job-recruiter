package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.EmailTemplateTypeEnum;
import lombok.Data;

@Data
public class EmailTemplateReq {
    private EmailTemplateTypeEnum emailType;
    private String emailSubject;
    private String emailBody;
}
