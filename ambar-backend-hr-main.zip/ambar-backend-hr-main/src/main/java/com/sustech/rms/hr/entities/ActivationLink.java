package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.*;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ActivationLink extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_activation_link_pk_id")
    private Long id;

    @Column(unique = true, nullable = false)
    @Builder.Default
    private String code = UUID.randomUUID().toString();

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "application_id")
    private Application application;

    @Builder.Default
    @Column(nullable = false)
    private Boolean active = false;

    @Column(nullable = false)
    private String password;
}
