package com.sustech.rms.hr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@SpringBootApplication
public class RMSHRApp {

	public static void main(String[] args) throws IOException {
		Files.createDirectories(Paths.get("uploads"));
		SpringApplication.run(RMSHRApp.class, args);
	}


}
