package com.sustech.rms.hr.projection;

public interface CustomCompliance {
    Long getId();

    String getDocument();

    String getNotes();

    String getSource();
}
