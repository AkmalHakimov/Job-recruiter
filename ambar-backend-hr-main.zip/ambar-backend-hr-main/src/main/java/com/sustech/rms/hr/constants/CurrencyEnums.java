package com.sustech.rms.hr.constants;

public enum CurrencyEnums {
    AUD;
}
