package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobRequisitionSummary;
import com.sustech.rms.hr.projection.JobRequisitionSummaryProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface JobRequisitionSummaryRepository extends JpaRepository<JobRequisitionSummary, Long> {
    Optional<JobRequisitionSummary> findByRequisitionId(Long reqId);
    Optional<JobRequisitionSummaryProjection> findByRequisitionIdOrderByIdAsc(Long reqId);
}
