package com.sustech.rms.hr.dto.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Setter
@Getter
public class ResetPasswordDto {
    @NotNull
    private String email;
    @NotNull
    private String currentPassword;
    @NotNull
    private String resetPassword;
    @NotNull
    private String code;
}
