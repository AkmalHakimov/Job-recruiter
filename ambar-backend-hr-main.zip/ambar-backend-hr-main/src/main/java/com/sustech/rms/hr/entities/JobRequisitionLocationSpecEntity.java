package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.CityRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_req_loc_spec")
@NoArgsConstructor
public class JobRequisitionLocationSpecEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_REQ_LOC_SPEC_PK_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    private JobPositionEntity jobPosition;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_DMGR_CITY_REF_PK_ID")
    private CityRefEntity city;


    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "D_MAX_DIST_NUM")
    private float distance;

    @Column(name = "V_DIST_UNIT_CD")
    private String distanceUnit;

    @Column(name = "V_MAND_LOC_IND")
    private Boolean mandatory;

    @Column(name = "D_WGHT_NUM")
    private float weight;

    @Column(name = "V_REMT_IND")
    private Boolean remote;

    @Column(name = "V_JOB_REQ_LOC_NOTE_TXT")
    private String note;


    public JobRequisitionLocationSpecEntity(JobPositionEntity jobPosition, CityRefEntity city, float distance, Boolean mandatory, float weight, Boolean remote) {
        this.jobPosition = jobPosition;
        this.city = city;
        this.distance = distance;
        this.mandatory = mandatory;
        this.weight = weight;
        this.remote = remote;
    }

    public JobRequisitionLocationSpecEntity changer(JobPositionEntity jobPosition, CityRefEntity city, float distance, Boolean mandatory, float weight, Boolean remote, String note) {
        this.jobPosition = jobPosition;
        this.city = city;
        this.distance = distance;
        this.mandatory = mandatory;
        this.weight = weight;
        this.remote = remote;
        this.note = note;
        return this;
    }

    public JobRequisitionLocationSpecEntity setNewValue(JobPositionEntity newJobPosition) {
        this.id = null;
        this.jobPosition = newJobPosition;
        return this;
    }

    @Override
    public JobRequisitionLocationSpecEntity clone() {
        try {
            JobRequisitionLocationSpecEntity clone = (JobRequisitionLocationSpecEntity) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
