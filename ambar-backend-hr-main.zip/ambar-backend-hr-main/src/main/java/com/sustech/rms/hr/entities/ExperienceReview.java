package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_experience_review",
        uniqueConstraints = @UniqueConstraint(columnNames = {"experience_id", "application_id"}))
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ExperienceReview extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_experience_review_pk_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "experience_id")
    private JobExperienceSpecEntity experience;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    private Application application;

    private Byte mark;//100 50 0. default null
}
