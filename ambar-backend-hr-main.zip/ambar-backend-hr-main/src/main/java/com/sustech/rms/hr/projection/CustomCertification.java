package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomCertification {
    Long getId();

    @Value("#{target.jobCertificateRef?.description}")
    String getDocument();

    @Value("#{target.note}")
    String getNotes();

    default String getSource() {
        return "Certification";
    }
}
