package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface JobWorkAuthSpecProjection {
    Long getId();

    @Value("#{target.jobPosition.id}")
    Long getPositionId();

    JobWorkAuthProjection getJobWorkAuthRef();

    Float getWeight();

    Boolean getMandatory();
    String getNote();
}
