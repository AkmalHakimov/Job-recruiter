package com.sustech.rms.hr.dto.response;

import lombok.Data;

@Data
public class IdResponse {
    private Long id;
}
