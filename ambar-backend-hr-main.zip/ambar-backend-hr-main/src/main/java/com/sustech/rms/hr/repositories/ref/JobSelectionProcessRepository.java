package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.ref.JobSelectionProcess;
import com.sustech.rms.hr.projection.JobSelectionProcessProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JobSelectionProcessRepository extends JpaRepository<JobSelectionProcess, Long> {

    JobSelectionProcess findByJobPosition(JobPositionEntity jobPosition);
    Optional<JobSelectionProcess> findByJobPositionId(Long positionId);
    Optional<JobSelectionProcessProjection> findByJobPositionIdOrderById(Long positionId);

//    int deleteByJobPositionId(Long positionId);
}
