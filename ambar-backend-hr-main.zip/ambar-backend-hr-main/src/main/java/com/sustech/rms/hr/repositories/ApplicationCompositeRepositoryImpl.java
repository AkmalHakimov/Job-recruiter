package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.constants.JobRequisitionEnums.ColumnCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.NumberOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.StringOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.TimestampOperatorCode;
import com.sustech.rms.hr.dto.request.SearchCriteriaRequest;
import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.repositories.page.RequestPage;
import com.sustech.rms.hr.repositories.page.ResponsePage;
import com.sustech.rms.hr.repositories.page.ResponsePageImpl;
import com.sustech.rms.hr.repositories.predicate.Contract;
import com.sustech.rms.hr.repositories.predicate.ContractHandler;
import com.sustech.rms.hr.repositories.predicate.PredicateSet;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ApplicationCompositeRepositoryImpl implements ApplicationCompositeRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ContractHandler contractHandler;

    @Override
    public ResponsePage<Application> findApplication(
            String searchValue, RequestPage requestPage) {

        ColumnCode[] codes = ColumnCode.values();
        List<SearchCriteriaRequest> scrl = new ArrayList<>();

        for (int i = 0; i < codes.length; i++) {
            String operatorCode = null;

            switch (codes[i]) {
                case JOBREQID:
                case APPLICANTID:
                case REQUISITIONID:
                    operatorCode = NumberOperatorCode.NUM_EQUAL.name();
                case REQUESTDATE:
                case STARTDATE:
                case ENDDATE:
                    operatorCode = TimestampOperatorCode.TIME_EQUAL.name();
                case PRIORITY:
                case STATUS:
                case PROGRESS:
                    operatorCode = StringOperatorCode.STR_EQUAL.name();
                case JOBSKILLTYPEDESC:
                case ORGDEPTNAME:
                case CITYNAME:
                case CITYCOUNTRYNAME:
                case APPLICANTNAME:
                case APPLICANTEMAIL:
                case APPLICANTCELL:
                default:
                    operatorCode = StringOperatorCode.STR_CONTAIN.name();
            }

            SearchCriteriaRequest scr = new SearchCriteriaRequest();
            scr.setColumnCode(codes[i].name());
            scr.setOperatorCode(operatorCode);
            scr.setSearchValue(searchValue);
            scrl.add(scr);
        }

        return selectJobRequisitions(scrl, requestPage, true);
    }

    @Override
    public ResponsePage<Application> findApplication(
            List<SearchCriteriaRequest> searchCriteriaList, RequestPage requestPage) {

        return selectJobRequisitions(
                searchCriteriaList, requestPage, false);
    }

    private Contract createPredicateContract(
            Root<Application> root,
            List<SearchCriteriaRequest> scrl) {

        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        Contract contract = contractHandler.newContract(root, builder);
        Iterator<SearchCriteriaRequest> scrlIter = scrl.iterator();

        while (scrlIter.hasNext()) {
            SearchCriteriaRequest scr = scrlIter.next();
            String columnCode = scr.getColumnCode();
            String operatorCode = scr.getOperatorCode();
            Object searchValue = scr.getSearchValue();

            contractHandler.addPredicate(
                    contract,
                    columnCode,
                    operatorCode,
                    searchValue);
        }

        return contract;
    }

    private Predicate buildBasePredicate(Contract contract, boolean isBlindQuery) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        List<Predicate> secondaryPredicateList = new ArrayList<Predicate>();
        List<PredicateSet> tertiaryPredicateSetList = contract.getPredicateSetList();
        Iterator<PredicateSet> pslIter = tertiaryPredicateSetList.iterator();

        while (pslIter.hasNext()) {
            PredicateSet ps = pslIter.next();
            Predicate secondaryPredicate = builder.or(ps.getPredicateArray());
            secondaryPredicateList.add(secondaryPredicate);
        }

        Predicate[] predArr = new Predicate[secondaryPredicateList.size()];

        Predicate basePredicate = (isBlindQuery)
                ? builder.or(secondaryPredicateList.toArray(predArr))
                : builder.and(secondaryPredicateList.toArray(predArr));

        return basePredicate;
    }

    private ResponsePage<Application> selectJobRequisitions(
            List<SearchCriteriaRequest> searchCriteriaList,
            RequestPage requestPage,
            boolean isBlindQuery) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        // Selecting the job requisitions based on the predicate.
        CriteriaQuery<Application> selectQuery = builder.createQuery(Application.class);
        Root<Application> root = selectQuery.from(Application.class);
        TypedQuery<Application> tSelectQuery = null;
        List<Application> result = null;

        Contract contract = createPredicateContract(root, searchCriteriaList);
        Predicate basePredicate = buildBasePredicate(contract, isBlindQuery);
        Order order = builder.desc(root.get("id"));

        selectQuery.select(root).where(basePredicate).orderBy(order);
        tSelectQuery = entityManager.createQuery(selectQuery);
        tSelectQuery.setFirstResult(requestPage.getStartingIndex());
        tSelectQuery.setMaxResults(requestPage.getPageLimit());
        result = tSelectQuery.getResultList();

        // Counting the job requistions based on the predicate.
        CriteriaQuery<Long> countQuery = builder.createQuery(Long.class);
        Root<Application> countRoot = countQuery.from(Application.class);
        TypedQuery<Long> tCountQuery = null;
        Long total = null;

        countQuery.select(builder.count(countRoot)).where(basePredicate);
        tCountQuery = entityManager.createQuery(countQuery);
        total = tCountQuery.getSingleResult();

        return new ResponsePageImpl<Application>(requestPage, result, total);
    }
}
