package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.JobRequisitionCertificateSpecEntity;
import com.sustech.rms.hr.projection.JobCertCpecProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface JobReqCertifRepository extends JpaRepository<JobRequisitionCertificateSpecEntity, Long> {

    Page<JobCertCpecProjection> findAllByJobPositionId(Long positionId, Pageable pageable);
    List<JobRequisitionCertificateSpecEntity> findAllByJobPosition(JobPositionEntity jobPosition);

    Optional<JobCertCpecProjection> getFirstByJobPositionId(Long positionId);

    List<JobRequisitionCertificateSpecEntity> findAllByJobPositionIdAndComplianceDocumentIsTrue(Long positionId);
}
