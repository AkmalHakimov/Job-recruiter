package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomExperienceReview {
    Long getId();

    @Value("#{target.experience?.industryRef?.name}")
    String getIndustry();

    @Value("#{target.experience?.industryDiscipline?.name}")
    String getDiscipline();

    @Value("#{target.experience?.jobPositionTypeRef?.description}")
    String getPosition();

    Byte getMark();
}
