package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.ref.JobPositionApprover;
import com.sustech.rms.hr.projection.JobPositionApproverProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobPositionApproverRepository extends JpaRepository<JobPositionApprover, Long> {
    Page<JobPositionApproverProjection> findAllByJobPositionEntityId(Long positionId, Pageable pageable);
    List<JobPositionApprover> findAllByJobPositionEntity(JobPositionEntity jobPosition);

    List<JobPositionApprover> findAllByIdIn(List<Long> ids);
}
