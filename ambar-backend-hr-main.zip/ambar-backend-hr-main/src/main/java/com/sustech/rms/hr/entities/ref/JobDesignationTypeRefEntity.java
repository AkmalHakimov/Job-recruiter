package com.sustech.rms.hr.entities.ref;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_job_designation_type_ref")
public class JobDesignationTypeRefEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_JOB_DESGNTN_TYP_REF_PK_ID")
  public Long id;

  @Column(name = "DESGNTN_TYP_CD")
  public String code;

  @Column(name = "DESGNTN_TYP_DESC")
  public String description;

  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  public JobDesignationTypeRefEntity(String code, String description) {
    this.code = code;
    this.description = description;
  }
}
