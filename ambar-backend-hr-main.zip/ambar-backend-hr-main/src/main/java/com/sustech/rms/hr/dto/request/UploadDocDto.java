package com.sustech.rms.hr.dto.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class UploadDocDto {
    @NotNull
    private Long complianceId;
    @NotNull
    private Long fileId;
}
