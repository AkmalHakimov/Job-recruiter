package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "hgz_offer_letter")
public class OfferLetter extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_offer_letter_pk_id")
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "offer_letter_hgz_application_pk_id", unique = true)
    private Application application;
    @Column(nullable = false)
    private LocalDate offerCreationDate;
    @Column(nullable = false)
    private LocalDate offerAcceptanceDate;
    @Column(nullable = false)
    private LocalDate offerDueDate;
    @Column(nullable = false)
    private LocalDate dateOfJoining;
    @Column(nullable = false)
    private String payFrequency;
    @Column(nullable = false)
    private String salaryType;
    @Column(nullable = false)
    private String salaryWageRate;
    @Column(nullable = false)
    private String currencyType;
    @Column(nullable = false)
    @Builder.Default
    private Boolean sent = false;
}
