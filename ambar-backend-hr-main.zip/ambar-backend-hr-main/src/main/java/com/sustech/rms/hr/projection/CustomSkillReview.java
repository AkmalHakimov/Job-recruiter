package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomSkillReview {
    Long getId();

    @Value("#{target.skill?.jobSkillRef?.description}")
    String getSkill();

    @Value("#{target.skill?.jobPosition?.jobPositionType?.description}")
    String getDetails();

    @Value("#{target.skill?.experience}")
    Float getExperience();

    Byte getMark();
}
