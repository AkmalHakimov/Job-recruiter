package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomLocationReview {
    Long getId();

    @Value("#{target.location?.city?.country?.name}")
    String getCountry();

    @Value("#{target.location?.city?.name}")
    String getCity();

    @Value("#{target.location?.distance+' '+target.location?.distanceUnit}")
    String getDistance();

    Byte getMark();
}
