package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.JobPositionEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@Table(name = "hgz_job_position_approver",
        uniqueConstraints = @UniqueConstraint(columnNames = {"N_APPROVER_REF_PK_ID", "N_JOB_POSN_PK_ID"}))
public class JobPositionApprover implements Cloneable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_POSN_APP_PK_ID")
    private Long id;

    @JoinColumn(name = "N_APPROVER_REF_PK_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    private JobApprover jobApprover;

    @JoinColumn(name = "N_JOB_POSN_PK_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    private JobPositionEntity jobPositionEntity;

//    @Enumerated(EnumType.STRING)
    private String response;

    public JobPositionApprover(JobApprover jobApprover, JobPositionEntity jobPositionEntity) {
        this.jobApprover = jobApprover;
        this.jobPositionEntity = jobPositionEntity;
    }

    public JobPositionApprover setNewValue(JobPositionEntity jobPosition) {
        this.id = null;
        this.jobPositionEntity = jobPosition;
        return this;
    }

    @Override
    public JobPositionApprover clone() {
        try {
            JobPositionApprover clone = (JobPositionApprover) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
