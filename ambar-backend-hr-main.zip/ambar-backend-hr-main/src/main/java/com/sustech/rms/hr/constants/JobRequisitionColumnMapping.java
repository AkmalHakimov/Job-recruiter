package com.sustech.rms.hr.constants;

import java.util.*;

public class JobRequisitionColumnMapping {
    public static final Map<String, List<String>> MAP;

    static {
        Map<String, List<String>> mapping = new HashMap<>();
        mapping.put(JobRequisitionEnums.ColumnCode.ID.name(), Arrays.asList("id"));
        mapping.put(JobRequisitionEnums.ColumnCode.JOBREQID.name(), Arrays.asList("id"));
        mapping.put(JobRequisitionEnums.ColumnCode.REQUESTDATE.name(), Arrays.asList("requestDate"));
        mapping.put(JobRequisitionEnums.ColumnCode.STARTDATE.name(), Arrays.asList("startDate"));
        mapping.put(JobRequisitionEnums.ColumnCode.ENDDATE.name(), Arrays.asList("endDate"));
        mapping.put(JobRequisitionEnums.ColumnCode.JOBPOSITIONTYPE.name(), Arrays.asList("jobPositionType", "id"));
        mapping.put(JobRequisitionEnums.ColumnCode.ORGDEPARTMENT.name(), Arrays.asList("orgDepartment", "id"));
        mapping.put(JobRequisitionEnums.ColumnCode.CITY.name(), Arrays.asList("city", "id"));
        mapping.put(JobRequisitionEnums.ColumnCode.PRIORITY.name(), Arrays.asList("priority"));
        mapping.put(JobRequisitionEnums.ColumnCode.STATUS.name(), Arrays.asList("status"));
        mapping.put(JobRequisitionEnums.ColumnCode.PROGRESS.name(), Arrays.asList("progress"));

        mapping.put(JobRequisitionEnums.ColumnCode.JOBSKILLTYPEDESC.name(), Arrays.asList("jobPositionType", "description"));
        mapping.put(JobRequisitionEnums.ColumnCode.ORGDEPTNAME.name(), Arrays.asList("orgDepartment", "name"));
        mapping.put(JobRequisitionEnums.ColumnCode.CITYNAME.name(), Arrays.asList("city", "name"));
        mapping.put(JobRequisitionEnums.ColumnCode.CITYCOUNTRYNAME.name(), Arrays.asList("city", "country", "name"));

        mapping.put(JobRequisitionEnums.ColumnCode.APPLICANTID.name(), Arrays.asList("applicant", "id"));
        mapping.put(JobRequisitionEnums.ColumnCode.REQUISITIONID.name(), Arrays.asList("requisition", "id"));
        mapping.put(JobRequisitionEnums.ColumnCode.APPLICANTNAME.name(), Arrays.asList("applicant", "firstName"));
        mapping.put(JobRequisitionEnums.ColumnCode.APPLICANTEMAIL.name(), Arrays.asList("applicant", "email"));
        mapping.put(JobRequisitionEnums.ColumnCode.APPLICANTCELL.name(), Arrays.asList("applicant", "mobile"));
        mapping.put(JobRequisitionEnums.ColumnCode.PROFILESCORE.name(), Arrays.asList("profileScore"));
        mapping.put(JobRequisitionEnums.ColumnCode.REVIEWSCORE.name(), Arrays.asList("reviewScore"));
        mapping.put(JobRequisitionEnums.ColumnCode.MISSINGITEMS.name(), Arrays.asList("missingItems"));
        mapping.put(JobRequisitionEnums.ColumnCode.CURRENTSALARY.name(), Arrays.asList("applicant", "currentSalary"));
        mapping.put(JobRequisitionEnums.ColumnCode.EXPECTEDSALARY.name(), Arrays.asList("applicant", "expectedSalary"));
        mapping.put(JobRequisitionEnums.ColumnCode.TOTALEXPERIENCE.name(), Arrays.asList("applicant", "totalExperience"));

        mapping.put(JobRequisitionEnums.InterviewColumnCode.INTERVIEWAPPLICANTNAME.name(), Arrays.asList("application", "applicant", "firstName"));
        mapping.put(JobRequisitionEnums.InterviewColumnCode.INTERVIEWAPPLICANTSTATUS.name(), Arrays.asList("application", "status"));
        mapping.put(JobRequisitionEnums.InterviewColumnCode.INTERVIEWSTEPID.name(), Arrays.asList("step", "id"));
        mapping.put(JobRequisitionEnums.InterviewColumnCode.INTERVIEWSCHEDULED.name(), Arrays.asList("scheduled"));
        mapping.put(JobRequisitionEnums.InterviewColumnCode.INTERVIEWSTATUS.name(), Arrays.asList("status"));
        MAP = Collections.unmodifiableMap(mapping);
    }
}
