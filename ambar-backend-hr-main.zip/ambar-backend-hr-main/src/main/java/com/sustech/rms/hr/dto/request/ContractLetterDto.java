package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.ContractTypeEnum;
import com.sustech.rms.hr.entities.EmployeeOnboardingDocument;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
public class ContractLetterDto {
    @NotNull
    private Long applicationId;

    @NotNull
    private LocalDate contractCommencementDate;

    private Long hoursOfOperation;

    private String pay;

    private String location;

    @NotNull
    private String governingLaw;

    private String industrialInstrument;

    private LocalDate dateOfAgreement;

    private String services;

    private String noticePeriod;

    private String name;

    private Long numberOfDays;

    private String liabilityRequirement;
    private List<EmployeeOnboardingDocument> employeeOnboardingDocuments;
    private String fee;
}
