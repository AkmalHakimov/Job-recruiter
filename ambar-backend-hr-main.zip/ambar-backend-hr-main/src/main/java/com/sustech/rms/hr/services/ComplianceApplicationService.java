package com.sustech.rms.hr.services;

import com.sustech.rms.hr.dto.request.ChangeStatusDocDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.entities.ComplianceApplication;
import com.sustech.rms.hr.repositories.ComplianceApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ComplianceApplicationService {
    private final ComplianceApplicationRepository complianceApplicationRepository;

    public ApiResponse changeStatus(ChangeStatusDocDto dto) {
        ComplianceApplication complianceApplication = complianceApplicationRepository.getReferenceById(dto.getComplianceId());
        complianceApplication.setStatus(dto.getStatus().toString());
        complianceApplicationRepository.save(complianceApplication);
        return ApiResponse.builder().build();
    }
}
