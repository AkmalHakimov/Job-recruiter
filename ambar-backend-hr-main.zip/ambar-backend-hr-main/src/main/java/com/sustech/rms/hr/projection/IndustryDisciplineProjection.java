package com.sustech.rms.hr.projection;

public interface IndustryDisciplineProjection {
    Long getId();
    String getName();
    String getDescription();
}
