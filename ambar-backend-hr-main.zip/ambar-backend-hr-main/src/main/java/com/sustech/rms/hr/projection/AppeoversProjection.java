package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.entities.ref.JobApprover;
import com.sustech.rms.hr.entities.ref.JobDesignationTypeRefEntity;
import com.sustech.rms.hr.entities.ref.OrgDepartmentRefEntity;

import java.util.List;

public interface AppeoversProjection {

    List<JobApprover> getApprovers();


    List<OrgDepartmentRefEntity> getDepartment();

    List<JobDesignationTypeRefEntity> getDesignation();

}
