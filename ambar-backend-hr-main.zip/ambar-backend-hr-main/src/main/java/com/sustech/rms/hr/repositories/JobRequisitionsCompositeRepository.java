package com.sustech.rms.hr.repositories;

import java.util.List;

import com.sustech.rms.hr.dto.request.SearchCriteriaRequest;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.repositories.page.RequestPage;
import com.sustech.rms.hr.repositories.page.ResponsePage;

public interface JobRequisitionsCompositeRepository {

    public ResponsePage<JobPositionEntity> findJobRequisitions(RequestPage requestPage);

    public ResponsePage<JobPositionEntity> findJobRequisitions(
            String searchValue, RequestPage requestPage);

    public ResponsePage<JobPositionEntity> findJobRequisitions(
            List<SearchCriteriaRequest> criteria, RequestPage requestPage);

}
