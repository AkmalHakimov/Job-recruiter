package com.sustech.rms.hr.projection;


import org.springframework.beans.factory.annotation.Value;

public interface JobQualSpecProjection {
    Long getId();

    @Value("#{target.jobQualityRef}")
    JobCertREfProjection getJobQualityRef();

    @Value("#{target.jobPosition.id}")
    Long getJobPositionId();

    Boolean getMandatory();

    Float getWeight();
    String getNote();
    Boolean getComplianceDocument();
}
