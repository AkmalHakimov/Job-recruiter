package com.sustech.rms.hr.projection;

import java.time.LocalDate;

public interface CustomComplianceApplication {
    Long getId();

    CustomCompliance getCompliance();

    CustomCertification getCertification();

    CustomQualification getQualification();

    String getStatus();

    LocalDate getDueDate();

    LocalDate getSubmittedOn();

    LocalDate getApprovedOn();

    CustomAttachment getFile();
    CustomAttachment getApplicantFile();
}
