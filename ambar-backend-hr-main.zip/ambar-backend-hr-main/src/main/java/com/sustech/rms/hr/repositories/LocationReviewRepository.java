package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.LocationReview;
import com.sustech.rms.hr.projection.CustomLocationReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

public interface LocationReviewRepository extends JpaRepository<LocationReview, Long> {
    LocationReview findByApplication(Application application);
    CustomLocationReview findByApplicationId(Long application);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);
}
