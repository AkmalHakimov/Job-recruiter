package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.JobQualityRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_req_qual_spec")
@NoArgsConstructor
public class JobRequisitionQualifSpecEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_REQ_QUAL_SPEC_PK_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    private JobPositionEntity jobPosition;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_QUAL_REF_PK_ID")
    private JobQualityRefEntity jobQualityRef;

    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "V_MAND_QUAL_IND")
    private Boolean mandatory;

    @Column(name = "D_WGHT_NUM")
    private float weight;

    @Column(name = "V_JOB_REQ_QUAL_NOTE_TXT")
    private String note;

    @Column(name = "compliance_document")
    private Boolean complianceDocument;

    public JobRequisitionQualifSpecEntity(JobPositionEntity jobPosition, JobQualityRefEntity jobQualityRef, Boolean mandatory, float weight, String note, Boolean complianceDocument) {
        this.jobPosition = jobPosition;
        this.jobQualityRef = jobQualityRef;
        this.mandatory = mandatory;
        this.weight = weight;
        this.note = note;
        this.complianceDocument = complianceDocument;
    }

    public JobRequisitionQualifSpecEntity setNewValues(JobPositionEntity jobPosition) {
        this.id = null;
        this.jobPosition = jobPosition;
        return this;
    }

    @Override
    public JobRequisitionQualifSpecEntity clone() {
        try {
            JobRequisitionQualifSpecEntity clone = (JobRequisitionQualifSpecEntity) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
