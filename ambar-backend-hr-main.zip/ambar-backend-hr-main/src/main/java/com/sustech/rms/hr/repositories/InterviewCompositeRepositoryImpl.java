package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.constants.JobRequisitionEnums.InterviewColumnCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.NumberOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.StringOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.TimestampOperatorCode;
import com.sustech.rms.hr.dto.request.SearchCriteriaRequest;
import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.Interview;
import com.sustech.rms.hr.repositories.page.RequestPage;
import com.sustech.rms.hr.repositories.page.ResponsePage;
import com.sustech.rms.hr.repositories.page.ResponsePageImpl;
import com.sustech.rms.hr.repositories.predicate.Contract;
import com.sustech.rms.hr.repositories.predicate.ContractHandler;
import com.sustech.rms.hr.repositories.predicate.PredicateSet;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class InterviewCompositeRepositoryImpl implements InterviewCompositeRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ContractHandler contractHandler;

    @Override
    public ResponsePage<Interview> findInterview(
            Long requisitionId,
            String searchValue, RequestPage requestPage) {

        InterviewColumnCode[] codes = InterviewColumnCode.values();
        List<SearchCriteriaRequest> scrl = new ArrayList<>();

        for (int i = 0; i < codes.length; i++) {
            String operatorCode = null;

            switch (codes[i]) {
                case INTERVIEWSTEPID:
                    operatorCode = NumberOperatorCode.NUM_EQUAL.name();
                    break;
                case INTERVIEWSCHEDULED:
                    operatorCode = TimestampOperatorCode.TIME_EQUAL.name();
                    break;
                case INTERVIEWSTATUS:
                case INTERVIEWAPPLICANTSTATUS:
                    operatorCode = StringOperatorCode.STR_EQUAL.name();
                    break;
                case INTERVIEWAPPLICANTNAME:
                default:
                    operatorCode = StringOperatorCode.STR_CONTAIN.name();
            }

            SearchCriteriaRequest scr = new SearchCriteriaRequest();
            scr.setColumnCode(codes[i].name());
            scr.setOperatorCode(operatorCode);
            scr.setSearchValue(searchValue);
            scrl.add(scr);
        }

        return selectJobRequisitions(requisitionId, scrl, requestPage, true);
    }

    @Override
    public ResponsePage<Interview> findInterview(
            Long requisitionId,
            List<SearchCriteriaRequest> searchCriteriaList, RequestPage requestPage) {

        return selectJobRequisitions(requisitionId,
                searchCriteriaList, requestPage, false);
    }

    private Contract createPredicateContract(
            Root<Interview> root,
            List<SearchCriteriaRequest> scrl) {

        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        Contract contract = contractHandler.newContract(root, builder);
        Iterator<SearchCriteriaRequest> scrlIter = scrl.iterator();

        while (scrlIter.hasNext()) {
            SearchCriteriaRequest scr = scrlIter.next();
            String columnCode = scr.getColumnCode();
            String operatorCode = scr.getOperatorCode();
            Object searchValue = scr.getSearchValue();

            contractHandler.addPredicate(
                    contract,
                    columnCode,
                    operatorCode,
                    searchValue);
        }

        return contract;
    }

    private Predicate buildBasePredicate(Long requisitionId, Root<Interview> root, Contract contract, boolean isBlindQuery) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        List<Predicate> secondaryPredicateList = new ArrayList<>();
        List<PredicateSet> tertiaryPredicateSetList = contract.getPredicateSetList();
        Iterator<PredicateSet> pslIter = tertiaryPredicateSetList.iterator();

        while (pslIter.hasNext()) {
            PredicateSet ps = pslIter.next();
            Predicate secondaryPredicate = builder.or(ps.getPredicateArray());
            secondaryPredicateList.add(secondaryPredicate);
        }

        Predicate[] predArr = new Predicate[secondaryPredicateList.size()];
        Join<Interview, Application> applicationJoin = root.join("application");
        Predicate requisitionPredicate = builder.equal(applicationJoin.get("requisition"), requisitionId);

        Predicate basePredicate = (isBlindQuery)
                ? builder.and(builder.or(secondaryPredicateList.toArray(predArr)), builder.and(requisitionPredicate))
                : builder.and(builder.and(secondaryPredicateList.toArray(predArr)), builder.and(requisitionPredicate));

        return basePredicate;
    }

    private ResponsePage<Interview> selectJobRequisitions(
            Long requisitionId,
            List<SearchCriteriaRequest> searchCriteriaList,
            RequestPage requestPage,
            boolean isBlindQuery) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        // Selecting the job requisitions based on the predicate.
        CriteriaQuery<Interview> selectQuery = builder.createQuery(Interview.class);
        Root<Interview> root = selectQuery.from(Interview.class);
        TypedQuery<Interview> tSelectQuery = null;
        List<Interview> result = null;

        Contract contract = createPredicateContract(root, searchCriteriaList);
        Predicate basePredicate = buildBasePredicate(requisitionId, root, contract, isBlindQuery);
        Order order = builder.desc(root.get("id"));

        selectQuery.select(root).where(basePredicate).orderBy(order);
        tSelectQuery = entityManager.createQuery(selectQuery);
        tSelectQuery.setFirstResult(requestPage.getStartingIndex());
        tSelectQuery.setMaxResults(requestPage.getPageLimit());
        result = tSelectQuery.getResultList();

        // Counting the job requisitions based on the predicate.
        CriteriaQuery<Long> countQuery = builder.createQuery(Long.class);
        Root<Interview> countRoot = countQuery.from(Interview.class);
        Predicate countBasePredicate = buildBasePredicate(requisitionId, countRoot, contract, isBlindQuery);

        countQuery.select(builder.count(countRoot)).where(countBasePredicate);
        TypedQuery<Long> tCountQuery = entityManager.createQuery(countQuery);
        Long total = tCountQuery.getSingleResult();

        return new ResponsePageImpl<Interview>(requestPage, result, total);
    }
}
