package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_prs")
public class ProcessStep extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRS_PK_ID")
    private Long id;

    @JoinColumn(name = "PRS_REF_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ScreeningType screeningType;

    @JoinColumn(name = "PRS_TEMP_REF_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private JobRequsitionTemplate template;

    @Column(name = "PRS_STG")
    private Integer stage;

}
