package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.JobRequisitionSkillSpecEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobSkillSpecRepository extends JpaRepository<JobRequisitionSkillSpecEntity,Long> {
    Page<JobRequisitionSkillSpecEntity> findAllByJobPositionId(Long positionId, Pageable pageable);
    List<JobRequisitionSkillSpecEntity> findAllByJobPosition(JobPositionEntity jobPosition);

    Boolean existsByJobPositionId(Long positionId);
}
