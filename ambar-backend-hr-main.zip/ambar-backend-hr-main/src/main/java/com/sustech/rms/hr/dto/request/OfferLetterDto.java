package com.sustech.rms.hr.dto.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Setter
@Getter
public class OfferLetterDto {
    @NotNull
    private Long applicationId;
    @NotNull
    private LocalDate offerCreationDate;
    @NotNull
    private LocalDate offerAcceptanceDate;
    @NotNull
    private LocalDate offerDueDate;
    @NotNull
    private LocalDate dateOfJoining;
    @NotNull
    private String payFrequency;
    @NotNull
    private String salaryType;
    @NotNull
    private String salaryWageRate;
    @NotNull
    private String currencyType;
}
