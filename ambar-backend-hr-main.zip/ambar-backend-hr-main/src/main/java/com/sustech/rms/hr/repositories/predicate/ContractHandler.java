package com.sustech.rms.hr.repositories.predicate;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ContractHandler {

  @Autowired
  PredicateSetFactory factory;

  public Contract newContract(Root<?> root, CriteriaBuilder builder) {
    return new Contract(root, builder);
  }

  public void addPredicate(Contract contract, String colCode, String oprCode, Object value) {

    PredicateSet ps = contract.getPredicateSet(colCode);
//    oprCode="NUM_EQUAL";
    boolean stat = false;

    if (ps != null) {
      stat = ps.addPredicate(contract.getBuilder(), oprCode, value);
    } else {
      ps = factory.create(contract.getRoot(), colCode);
      if (ps != null) {
        stat = ps.addPredicate(contract.getBuilder(), oprCode, value);
        contract.addPredicateSet(ps);
      }
    }

    if (ps == null) {
      log.warn("The predicate set for ({}) column was not created.", colCode);
    }

    if (!stat) {
      log.warn("The predicate for ({}) column with ({}) operator and ({}) value was not added.",
          colCode, oprCode, value);
    }
  }
}
