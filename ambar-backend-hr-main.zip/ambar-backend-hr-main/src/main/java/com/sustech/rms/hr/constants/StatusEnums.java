package com.sustech.rms.hr.constants;

public enum StatusEnums {
    DRAFT,
    SUBMITTED,
    IN_REVIEW,
    REVIEW_APPROVED,
    REVIEW_DENIED,
    IN_INTERVIEW,
    REFERENCE_CHECK,
    COMPLIANCE_CHECK,
    CANDIDATE_APPROVED,
    CANDIDATE_DENIED,
    CANCELLED,
    COMPLETED,
}
