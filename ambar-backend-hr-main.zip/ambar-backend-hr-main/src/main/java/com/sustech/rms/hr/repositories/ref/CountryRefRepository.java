package com.sustech.rms.hr.repositories.ref;

import org.springframework.data.repository.CrudRepository;

import com.sustech.rms.hr.entities.ref.CountryRefEntity;

public interface CountryRefRepository extends CrudRepository<CountryRefEntity, Long> {

}
