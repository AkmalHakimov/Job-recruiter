package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.constants.EmailTemplateTypeEnum;
import com.sustech.rms.hr.entities.EmailTemplate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long> {
    Optional<EmailTemplate> findByEmailType(EmailTemplateTypeEnum emailType);
}
