package com.sustech.rms.hr.dto.request;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class ResumeRes {
    private Integer profileScore;
    private Integer missingMandatoryItems;
}
