package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.constants.CurrencyEnums;
import com.sustech.rms.hr.entities.ref.CityRefEntity;
import com.sustech.rms.hr.entities.ref.JobReqApplTypeRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import com.sustech.rms.hr.entities.temporary.RegulatoryTempEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_req_fincl_spec")
@NoArgsConstructor
public class JobRequisitionFinclSpecEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_REQ_FINCL_SPEC_PK_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    private JobPositionEntity jobPosition;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_APPL_TYP_REF_PK_ID")
    private JobReqApplTypeRefEntity jobReqApplTypeRef;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_DMGR_CITY_REF_PK_ID")
    private CityRefEntity city;


    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "V_MAND_FINCL_IND")
    private Boolean mandatory;

    @Column(name = "D_WGHT_NUM")
    private float weight;

    @Column(name = "V_FINCL_RATE_TYP_DESC")
    private String rateTypeDescription;

    @Column(name = "V_JOB_REQ_FINCL_NOTE_TXT")
    private String note;

    @Column(name = "D_COMPSTN_MIN_RATE_AMT")
    private double compositionMinRate;

    @Column(name = "D_COMPSTN_MAX_RATE_AMT")
    private double compositionMaxRate;

    @Column(name = "V_COMPSTN_CRNCY_CD")
    private CurrencyEnums compositionCurrencyCode;


    @Column(name = "D_INDSTRY_MIN_RATE_AMT")
    private double industryMinRate;

    @Column(name = "D_INDSTRY_MAX_RATE_AMT")
    private double industryMaxRate;

    @Column(name = "V_INDSTRY_CRNCY_CD")
    private CurrencyEnums industryCurrencyCode;


    @Column(name = "D_REGLTRY_MIN_RATE_AMT")
    private double regulatoryMinRate;

    @Column(name = "D_REGLTRY_MAX_RATE_AMT")
    private double regulatoryMaxRate;

    @Column(name = "V_REGLTRY_CRNCY_CD")
    private CurrencyEnums regulatoryCurrencyCode;

    @ManyToOne
    @JoinColumn(name = "regulatory_temp_id")
    private RegulatoryTempEntity regulatoryTempEntity;

    public JobRequisitionFinclSpecEntity(JobPositionEntity jobPosition,
                                         JobReqApplTypeRefEntity jobReqApplTypeRef,
                                         Boolean mandatory, float weight, String note,
                                         double compositionMinRate, double compositionMaxRate,
                                         CurrencyEnums compositionCurrencyCode, double industryMinRate,
                                         double industryMaxRate, CurrencyEnums industryCurrencyCode, RegulatoryTempEntity regulatoryTempEntity) {
        this.jobPosition = jobPosition;
        this.jobReqApplTypeRef = jobReqApplTypeRef;
        this.mandatory = mandatory;
        this.weight = weight;
        this.note = note;
        this.compositionMinRate = compositionMinRate;
        this.compositionMaxRate = compositionMaxRate;
        this.compositionCurrencyCode = compositionCurrencyCode;
        this.industryMinRate = industryMinRate;
        this.industryMaxRate = industryMaxRate;
        this.industryCurrencyCode = industryCurrencyCode;
        this.regulatoryTempEntity = regulatoryTempEntity;
    }

    public JobRequisitionFinclSpecEntity changer(JobPositionEntity jobPosition,
                                                 JobReqApplTypeRefEntity jobReqApplTypeRef,
                                                 Boolean mandatory, float weight, String note,
                                                 double compositionMinRate, double compositionMaxRate,
                                                 CurrencyEnums compositionCurrencyCode, double industryMinRate,
                                                 double industryMaxRate, CurrencyEnums industryCurrencyCode, RegulatoryTempEntity regulatoryTempEntity) {
        this.jobPosition = jobPosition;
        this.jobReqApplTypeRef = jobReqApplTypeRef;
        this.mandatory = mandatory;
        this.weight = weight;
        this.note = note;
        this.compositionMinRate = compositionMinRate;
        this.compositionMaxRate = compositionMaxRate;
        this.compositionCurrencyCode = compositionCurrencyCode;
        this.industryMinRate = industryMinRate;
        this.industryMaxRate = industryMaxRate;
        this.industryCurrencyCode = industryCurrencyCode;
        this.regulatoryTempEntity = regulatoryTempEntity;
        return this;
    }

    @Override
    public JobRequisitionFinclSpecEntity clone() {
        try {
            JobRequisitionFinclSpecEntity clone = (JobRequisitionFinclSpecEntity) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    public JobRequisitionFinclSpecEntity setNewValue(JobPositionEntity newJobPosition) {
        this.id = null;
        this.jobPosition = newJobPosition;
        return this;
    }
}
