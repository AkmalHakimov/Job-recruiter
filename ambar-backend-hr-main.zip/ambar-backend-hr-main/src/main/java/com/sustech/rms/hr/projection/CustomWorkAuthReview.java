package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomWorkAuthReview {
    Long getId();

    @Value("#{target.workAuth?.jobWorkAuthRef?.description}")
    String getWorkAuthType();

    @Value("#{target.workAuth?.note}")
    String getNotes();

    Byte getMark();
}
