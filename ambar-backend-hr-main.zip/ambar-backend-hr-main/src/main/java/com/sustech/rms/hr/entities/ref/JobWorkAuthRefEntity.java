package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "hgz_job_work_auth_ref")
public class JobWorkAuthRefEntity extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_JOB_WORK_AUTH_REF_PK_ID")
  private Long id;


  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "N_DMGR_CNTRY_REF_PK_ID")
  private CountryRefEntity country;


  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  @Column(name = "V_WORK_AUTH_TYP_CD")
  private String code;

  @Column(name = "V_WORK_AUTH_TYP_DESC")
  private String description;

  public JobWorkAuthRefEntity(String code, String description) {
    this.code = code;
    this.description = description;
  }
}
