package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.ContractLetter;
import com.sustech.rms.hr.projection.ContractLetterProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ContractLetterRepository extends JpaRepository<ContractLetter, Long> {
    Optional<ContractLetter> findByApplication(Application application);
    Optional<ContractLetterProjection> findByApplicationId(Long id);
}
