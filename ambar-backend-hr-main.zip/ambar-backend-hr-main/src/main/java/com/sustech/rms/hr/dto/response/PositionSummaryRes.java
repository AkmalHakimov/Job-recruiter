package com.sustech.rms.hr.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.sql.Timestamp;
import java.time.LocalDate;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PositionSummaryRes {
    private String hiringManager;
    private LocalDate targetDate;
    private String hrManager;
    private Integer targetOpen;
    private String status;
    private Long jobPositionId;
    private Timestamp requisitionDate;
    private Long departmentId;
    private String priority;
    private Integer onboarded;
    private Long requisitionId;
}
