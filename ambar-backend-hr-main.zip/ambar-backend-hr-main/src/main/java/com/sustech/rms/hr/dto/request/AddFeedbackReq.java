package com.sustech.rms.hr.dto.request;

import lombok.Data;

@Data
public class AddFeedbackReq {
    private Boolean attended;
    private Boolean meetsRequirement;
    private String notes;
}
