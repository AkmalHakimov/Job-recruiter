package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.ApproverResponseEnum;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ChangeApprovalResponseReq {
    @NotNull
    private Long id;
    @NotNull
    private ApproverResponseEnum response;
}
