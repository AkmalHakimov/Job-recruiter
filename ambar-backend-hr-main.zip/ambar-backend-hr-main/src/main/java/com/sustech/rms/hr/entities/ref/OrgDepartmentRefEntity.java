package com.sustech.rms.hr.entities.ref;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_org_department_ref")
public class OrgDepartmentRefEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_ORG_DEPT_REF_PK_ID")
  private Long id;

  @Column(name = "V_DEPT_CODE")
  private String code;

  @Column(name = "V_DEPT_NAME")
  private String name;

  public OrgDepartmentRefEntity(String code, String name) {
    this.code = code;
    this.name = name;
  }
}
