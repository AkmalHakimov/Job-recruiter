package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobCertificateRefEntity;
import com.sustech.rms.hr.projection.JobCertREfProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobCertificationRefRepository extends JpaRepository<JobCertificateRefEntity,Long> {

    List<JobCertREfProjection> findAllByOrderById();
}
