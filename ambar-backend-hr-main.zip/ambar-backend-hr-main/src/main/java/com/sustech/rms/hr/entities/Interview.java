package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.JobRequsitionInterviewerUser;
import com.sustech.rms.hr.entities.ref.ProcessRequsitionSteps;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "hgz_interview")
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Interview extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_interview_pk_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false)
    private Application application;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "step_id", nullable = false)
    private ProcessRequsitionSteps step;

    private Timestamp scheduled;
    private LocalTime time;

//    @Enumerated(EnumType.STRING)
    private String status;

    @Column(columnDefinition = "text")
    private String note;

    private Boolean meetsRequirement;
    private Boolean attended;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "hgz_interview_user",
            joinColumns = @JoinColumn(name = "hgz_interview_pk_id",
                    referencedColumnName = "hgz_interview_pk_id"),
            inverseJoinColumns = @JoinColumn(name = "PRS_REF_INTW_PK_ID",
                    referencedColumnName = "PRS_REF_INTW_PK_ID"))
    private List<JobRequsitionInterviewerUser> interviewUsers;
}
