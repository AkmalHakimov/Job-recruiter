package com.sustech.rms.hr.dto.request;

public enum ReviewTypeEnum {
    QUALIFICATION,
    CERTIFICATION,
    WORK_AUTH,
    LOCATION,
    FINANCIAL,
    EXPERIENCE,
    SKILL
}
