package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.JobRoleRespSpecEntity;
import com.sustech.rms.hr.projection.JobRoleResProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface JobRoleResSpecRepository extends JpaRepository<JobRoleRespSpecEntity,Long> {
    Page<JobRoleResProjection> findAllByJobPositionId(Long positionId, Pageable pageable);
    List<JobRoleRespSpecEntity> findAllByJobPosition(JobPositionEntity jobPosition);

    Optional<JobRoleResProjection> getFirstByJobPositionId(Long positionId);
}
