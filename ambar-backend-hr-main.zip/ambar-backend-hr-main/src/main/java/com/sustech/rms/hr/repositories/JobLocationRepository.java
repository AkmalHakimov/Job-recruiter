package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.JobRequisitionLocationSpecEntity;
import com.sustech.rms.hr.projection.JobLocationProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface JobLocationRepository extends JpaRepository<JobRequisitionLocationSpecEntity, Long> {
    @Query("select t from JobRequisitionLocationSpecEntity t where t.jobPosition.id=:positionId")
    Optional<JobRequisitionLocationSpecEntity> findLocation(Long positionId);

    Optional<JobLocationProjection> findByJobPositionId(Long positionId);

    JobRequisitionLocationSpecEntity findByJobPosition(JobPositionEntity jobPosition);
}
