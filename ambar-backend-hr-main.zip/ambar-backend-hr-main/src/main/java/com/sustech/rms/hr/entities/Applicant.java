package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_applicant")
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Applicant extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_applicant_pk_id")
    private Long id;
    @Column(nullable = false)
    private String firstName;
    @Column(nullable = false)
    private String middleName;
    @Column(nullable = false)
    private String surName;
    @Column(nullable = false)
    private String title;
    @Column(nullable = false)
    private String email;
    @Column(nullable = false)
    private String mobile;
    @Column(nullable = false)
    private String phone;
//   @Column(nullable = false)
//    private Byte minExperience;
//    @Column(nullable = false)
//    private Byte maxExperience;
    @Column(nullable = false)
    private Byte totalExperience;
    @Column(nullable = false)
    private Long currentSalary;
    @Column(nullable = false)
    private Long expectedSalary;
    @Column(nullable = false)
    private String currentSalOption;
    @Column(nullable = false)
    private String expectedSalOption;
}
