package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.ComplianceApplicationStatus;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Setter
@Getter
public class ChangeStatusDocDto {
    @NotNull
    private Long complianceId;
    @NotNull
    private ComplianceApplicationStatus status;
}
