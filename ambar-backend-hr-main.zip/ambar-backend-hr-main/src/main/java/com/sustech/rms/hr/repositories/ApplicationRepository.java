package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.projection.CustomApplication;
import com.sustech.rms.hr.projection.CustomApplication1;
import com.sustech.rms.hr.projection.CustomContractApplication;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ApplicationRepository extends JpaRepository<Application, Long>, ApplicationCompositeRepository {
    Boolean existsByApplicantIdAndRequisitionId(Long applicantId, Long requisitionId);

    CustomApplication findByIdOrderById(Long id);
    CustomApplication1 findByIdOrderByIdAsc(Long id);
    CustomContractApplication findByIdOrderByIdDesc(Long id);

    List<Application> findAllByRequisitionId(Long id);

    Integer countAllByRequisitionAndStatus(JobPositionEntity requisition, String status);

    List<Application> findAllByIdIn(List<Long> ids);

}
