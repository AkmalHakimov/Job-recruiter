package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobPositionTypeRefEntity;
import com.sustech.rms.hr.projection.JobCertREfProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobPositionTypeRefRepository extends JpaRepository<JobPositionTypeRefEntity,Long> {

    List<JobCertREfProjection> findAllByOrderById();
}
