package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.ApplicationStatusEnum;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class ChangeStatusBulkReq {
    @NotNull
    private ApplicationStatusEnum status;
    @NotEmpty
    private List<Long> ids;
}
