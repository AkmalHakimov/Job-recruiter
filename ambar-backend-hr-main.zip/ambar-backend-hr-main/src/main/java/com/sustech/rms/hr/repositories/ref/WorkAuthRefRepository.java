package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobWorkAuthRefEntity;
import com.sustech.rms.hr.projection.JobWorkAuthProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkAuthRefRepository extends JpaRepository<JobWorkAuthRefEntity,Long> {

    List<JobWorkAuthProjection> findAllByOrderById();
}
