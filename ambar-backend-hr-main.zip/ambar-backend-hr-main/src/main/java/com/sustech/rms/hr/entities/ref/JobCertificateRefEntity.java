package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_job_cert_ref")
public class JobCertificateRefEntity extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_JOB_CERT_REF_PK_ID")
  private Long id;

  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "N_JOB_SKILL_REF_PK_ID")
  private JobSkillRefEntity jobSkillRef;

  @Column(name = "V_CERT_CD")
  private String code;

  @Column(name = "V_CERT_DESC")
  private String description;

  @Column(name = "V_CERT_BY_INST_NM")
  private String certificateByInst;

  public JobCertificateRefEntity(String code, String description) {
    this.code = code;
    this.description = description;
  }
}
