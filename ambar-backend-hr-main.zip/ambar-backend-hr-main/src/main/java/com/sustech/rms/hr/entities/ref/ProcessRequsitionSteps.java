package com.sustech.rms.hr.entities.ref;


import com.sustech.rms.hr.constants.ProcessStatusEnum;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hgz_job_req_steps")
public class ProcessRequsitionSteps extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRS_REF_STP_PK_ID")
    private Long id;

    @JoinColumn(name = "N_DMGR_CITY_REF_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CityRefEntity cityRef;

    @Column(name = "PRS_REQ_STG")
    private Integer stage;

    @Enumerated(EnumType.STRING)
    @Column(name = "PRS_REQ_STP_STS")
    private ProcessStatusEnum status;

    @JoinColumn(name = "PRS_REF_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ScreeningType screeningType;

    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private JobPositionEntity jobPositionEntity;

    @JoinColumn(name = "PRS_TEMP_REF_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private JobRequsitionTemplate template;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "hgz_prs_req_step_intw_user",
            joinColumns = @JoinColumn(name = "PRS_REF_STP_PK_ID",
                    referencedColumnName = "PRS_REF_STP_PK_ID"),
            inverseJoinColumns = @JoinColumn(name = "PRS_REF_INTW_PK_ID",
                    referencedColumnName = "PRS_REF_INTW_PK_ID"))
    private List<JobRequsitionInterviewerUser> interviewUsers;

    public ProcessRequsitionSteps(CityRefEntity cityRef, Integer stage, ProcessStatusEnum status, ScreeningType screeningType, JobPositionEntity jobPositionEntity, JobRequsitionTemplate template, List<JobRequsitionInterviewerUser> interviewUsers) {
        this.cityRef = cityRef;
        this.stage = stage;
        this.status = status;
        this.screeningType = screeningType;
        this.jobPositionEntity = jobPositionEntity;
        this.template = template;
        this.interviewUsers = interviewUsers;
    }

    public ProcessRequsitionSteps setNewValue(JobPositionEntity jobPosition) {
        this.id = null;
        this.jobPositionEntity = jobPosition;
        return this;
    }

    @Override
    public ProcessRequsitionSteps clone() {
        try {
            ProcessRequsitionSteps clone = (ProcessRequsitionSteps) super.clone();
            clone.setInterviewUsers(new ArrayList<>(this.interviewUsers));
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
