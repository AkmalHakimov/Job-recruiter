package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.entities.ref.JobDesignationTypeRefEntity;
import com.sustech.rms.hr.entities.ref.OrgDepartmentRefEntity;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;

public interface JobPositionApproverProjection {
    Long getId();

    @Value("#{target.jobApprover.fullName}")
    String getFullName();

    @Value("#{target.jobApprover.email}")
    String getEmail();

    @Value("#{target.jobApprover.departmentRef}")
    List<OrgDepartmentRefEntity> getDepartmentRef();

    @Value("#{target.jobApprover.designationTypeRef}")
    List<JobDesignationTypeRefEntity> getDesignationTypeRef();

    String getResponse();
}
