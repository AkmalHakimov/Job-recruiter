package com.sustech.rms.hr.constants;

public enum InterviewStatusEnum {
    SCHEDULED,
    REVIEW,
    COMPLETE,
    CANCELLED
}
