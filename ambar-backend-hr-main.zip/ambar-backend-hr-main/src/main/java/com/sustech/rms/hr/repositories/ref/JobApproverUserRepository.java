package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobApprover;
import com.sustech.rms.hr.projection.JobApproverProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface JobApproverUserRepository extends JpaRepository<JobApprover, Long> {

    @Query(value = "select t.N_APPROVER_REF_PK_ID as id," +
            "t.APR_FULLNAME as fullName," +
            "t.APR_EMAIL as email " +
            " from hgz_approver_user_ref t " +
            " where upper(t.APR_FULLNAME) like concat('%',upper(:fullName),'%') " +
            " and t.N_APPROVER_REF_PK_ID not in (select N_APPROVER_REF_PK_ID from hgz_job_position_approver where N_JOB_POSN_PK_ID=:positionId)" +
            " order by id " +
            " limit 10",
            nativeQuery = true)
    List<JobApproverProjection> findFirst10ByFullNameContainingIgnoreCase(String fullName, Long positionId);

}
