package com.sustech.rms.hr.dto.request;

import lombok.Data;

@Data
public class ChangeReviewValueReq {
    private ReviewTypeEnum reviewTypeEnum;
    private ReviewValueEnum reviewValueEnum;
    private Long applicationId;
    private Long itemId;
}
