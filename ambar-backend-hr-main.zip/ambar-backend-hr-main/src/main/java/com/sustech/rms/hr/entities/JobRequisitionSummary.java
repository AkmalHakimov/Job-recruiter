package com.sustech.rms.hr.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_requisition_summary")
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class JobRequisitionSummary {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_job_requisition_summary_pk_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requisition_id", unique = true)
    private JobPositionEntity requisition;

    private String hiringManager;
    private String hrManager;

}
