package com.sustech.rms.hr.services;

import com.sustech.rms.hr.dto.request.CheckUserPasswordDto;
import com.sustech.rms.hr.dto.request.ResetPasswordDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.dto.response.ApplicantDetailsDto;
import com.sustech.rms.hr.entities.ActivationLink;
import com.sustech.rms.hr.entities.Applicant;
import com.sustech.rms.hr.repositories.ActivationLinkRepository;
import com.sustech.rms.hr.repositories.ApplicantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class ActivationLinkService {
    private final ActivationLinkRepository activationLinkRepository;
    private final ApplicantRepository applicantRepository;

    public ApiResponse getApplicantDetails(String code) {
        ActivationLink activationLink = activationLinkRepository.findByCode(code).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        Applicant applicant = activationLink.getApplication().getApplicant();
        return ApiResponse.builder()
                .data(ApplicantDetailsDto.builder()
                        .name(applicant.getFirstName())
                        .email(applicant.getEmail())
                        .active(activationLink.getActive())
                        .build())
                .build();
    }


    public ApiResponse checkUserPassword(CheckUserPasswordDto dto) {
        ActivationLink activationLink = activationLinkRepository.findByCodeAndPasswordAndActiveIsFalse(dto.getCode(), dto.getPassword()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found or password is incorrect"));
        activationLink.setActive(true);
        activationLinkRepository.save(activationLink);
        return ApiResponse.builder()
                .message("success")
                .build();
    }

    public ApiResponse resetPassword(ResetPasswordDto dto) {
        applicantRepository.findFirstByEmail(dto.getEmail()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        ActivationLink activationLink = activationLinkRepository.findByCodeAndPassword(dto.getCode(), dto.getCurrentPassword()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found or password is incorrect"));
        activationLink.setPassword(dto.getResetPassword());
        activationLinkRepository.save(activationLink);
        return ApiResponse.builder()
                .message("Password has been changed")
                .build();
    }
}
