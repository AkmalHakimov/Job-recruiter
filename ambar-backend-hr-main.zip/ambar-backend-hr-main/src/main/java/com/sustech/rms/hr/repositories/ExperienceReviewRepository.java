package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.ExperienceReview;
import com.sustech.rms.hr.projection.CustomExperienceReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ExperienceReviewRepository extends JpaRepository<ExperienceReview, Long> {
    List<ExperienceReview> findAllByApplication(Application application);
    List<CustomExperienceReview> findAllByApplicationId(Long application);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);

    @Transactional
    @Modifying
    void deleteAllByExperienceId(Long id);
}
