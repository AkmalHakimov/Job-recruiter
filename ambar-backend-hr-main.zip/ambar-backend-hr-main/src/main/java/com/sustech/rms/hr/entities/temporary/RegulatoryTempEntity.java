package com.sustech.rms.hr.entities.temporary;

import com.sustech.rms.hr.entities.ref.CityRefEntity;
import com.sustech.rms.hr.entities.ref.CountryRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_regulatory_temporary")
@NoArgsConstructor
public class RegulatoryTempEntity extends AbstractEntity {


  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;
  @Column(name = "code")
  private String code;
  @ManyToOne
  @JoinColumn(name = "country_id")
  private CountryRefEntity country;
  @ManyToOne
  @JoinColumn(name = "state_id")
  private CityRefEntity state;
  @Column(name = "level")
  private int level;
  @Column(name = "D_MINIMUM_WAGE_HOURLY")
  private double minimumWageHourly;
  @Column(name = "D_MINIMUM_WAGE_DAILY")
  private double minimumWageDaily;
  @Column(name = "currency")
  private String currencyType;

}
