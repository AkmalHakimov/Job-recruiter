package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.entities.ref.JobRequsitionInterviewerUser;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface CustomInterview {
    Long getId();

    LocalDate getScheduled();

    LocalTime getTime();

    String getStatus();

    List<JobRequsitionInterviewerUser> getInterviewUsers();

    String getNote();

    Boolean getMeetsRequirement();
}
