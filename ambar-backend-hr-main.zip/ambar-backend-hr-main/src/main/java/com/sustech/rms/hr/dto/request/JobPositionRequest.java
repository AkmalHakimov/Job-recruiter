package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.PriorityEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobPositionRequest {
    @NotNull
    private Long industryDisciplineId;
    @NotNull
    private Long industryId;
    @NotNull
    private Long jobPositionTypeId;
    @NotNull
    private Integer targetOpen;
    @NotNull
    private Integer minReqExperience;
    @NotNull
    private Integer maxReqExperience;
    @NotNull
    private LocalDate startDate;
    @NotNull
    private LocalDate endDate;
    @NotNull
    private LocalDate targetDate;
    @NotNull
    private LocalDate requestDate;
    @NotNull
    private String description;
    @NotNull
    private PriorityEnum priorityEnum;

}
