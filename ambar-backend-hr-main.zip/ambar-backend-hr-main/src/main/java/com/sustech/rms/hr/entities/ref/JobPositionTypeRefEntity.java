package com.sustech.rms.hr.entities.ref;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_job_position_type_ref")
public class JobPositionTypeRefEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_JOB_POSN_TYP_REF_PK_ID")
  private Long id;

  @Column(name = "JOB_POSN_TYP_CD")
  private String code;

  @Column(name = "JOB_POSN_TYP_DESC")
  private String description;

  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  public JobPositionTypeRefEntity(String code, String description) {
    this.code = code;
    this.description = description;
  }
}
