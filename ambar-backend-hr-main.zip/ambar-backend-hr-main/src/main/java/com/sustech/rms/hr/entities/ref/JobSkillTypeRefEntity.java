//package com.sustech.rms.entities.ref;
//
//import javax.persistence.*;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Getter
//@Setter
//@Entity
//@Table(name = "hgz_job_skill_type_ref")
//public class JobSkillTypeRefEntity {
//
//  @Id
//  @GeneratedValue(strategy = GenerationType.IDENTITY)
//  @Column(name = "N_JOB_SKILL_TYP_REF_PK_ID")
//  public Long id;
//
//  @Column(name = "V_TYPE_CODE")
//  public String code;
//
//  @Column(name = "V_TYPE_DESC")
//  public String description;
//
//  @ManyToOne
//  @JoinColumn(name = "N_INDSTRY_DISCPLN_REF_PK_ID")
//  private IndustryDisciplineRefEntity industryDiscipline;
//
//}