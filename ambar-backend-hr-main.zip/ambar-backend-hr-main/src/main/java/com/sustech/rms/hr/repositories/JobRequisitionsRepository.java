package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface JobRequisitionsRepository
        extends PagingAndSortingRepository<JobPositionEntity, Long>, JobRequisitionsCompositeRepository {

}
