package com.sustech.rms.hr.entities.ref;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "hgz_dmgr_city_ref")
public class CityRefEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_DMGR_CITY_REF_PK_ID")
  private Long id;

  @Column(name = "V_CITY_CODE")
  private String code;

  @Column(name = "V_CITY_NAME")
  private String name;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "N_COUNTRY")
  private CountryRefEntity country;
}
