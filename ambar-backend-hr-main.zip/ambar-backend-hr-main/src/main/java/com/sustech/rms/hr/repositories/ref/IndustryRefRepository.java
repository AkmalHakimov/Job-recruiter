package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.OrgDepartmentRefEntity;
import com.sustech.rms.hr.projection.DepartmentRefProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IndustryRefRepository extends JpaRepository<OrgDepartmentRefEntity, Long> {

    List<DepartmentRefProjection> findAllByOrderById();
}
