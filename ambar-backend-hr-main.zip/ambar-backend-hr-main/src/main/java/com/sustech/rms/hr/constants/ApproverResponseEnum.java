package com.sustech.rms.hr.constants;

public enum ApproverResponseEnum {
    APPROVED,
    REJECTED,
    REQUESTED_REVISION
}
