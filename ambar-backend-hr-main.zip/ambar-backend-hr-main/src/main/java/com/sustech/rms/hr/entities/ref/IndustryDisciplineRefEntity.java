package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_industry_discpln_ref")
public class IndustryDisciplineRefEntity extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_INDSTRY_DISCPLN_REF_PK_ID")
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "N_INDSTRY_REF_PK_ID")
  private IndustryRefEntity industry;

  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  @Column(name = "V_DISCPLN_NM")
  private String name;

  @Column(name = "V_DISCPLN_DESC")
  private String description;

  public IndustryDisciplineRefEntity(String name, String description) {
    this.name = name;
    this.description = description;
  }
}
