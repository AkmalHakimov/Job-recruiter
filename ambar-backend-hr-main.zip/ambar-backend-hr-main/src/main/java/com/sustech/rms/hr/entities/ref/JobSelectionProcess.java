package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.constants.BCGLevelEnums;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_selection_prs")
public class JobSelectionProcess extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_SLC_PRS_PK_ID")
    private Long id;

    @Column(name = "N_JOB_SLC_BG_CHECK")
    private Boolean bcgCheck;

    @Enumerated(EnumType.STRING)
    @Column(name = "N_JOB_CHECK_LEVEL")
    private BCGLevelEnums checkLevel;

    @JoinColumn(name = "PRS_TEMP_REF_PK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private JobRequsitionTemplate template;

    @JoinColumn(name = "N_JOB_POSN_PK_ID", unique = true)
    @ManyToOne(fetch = FetchType.LAZY)
    private JobPositionEntity jobPosition;

    public JobSelectionProcess(Boolean bcgCheck, BCGLevelEnums checkLevel, JobRequsitionTemplate template, JobPositionEntity jobPosition) {
        this.bcgCheck = bcgCheck;
        this.checkLevel = checkLevel;
        this.template = template;
        this.jobPosition = jobPosition;
    }

    public JobSelectionProcess setNewValues(JobPositionEntity jobPositionEntity) {
        this.id = null;
        this.jobPosition = jobPositionEntity;
        return this;
    }

    @Override
    public JobSelectionProcess clone() {
        try {
            JobSelectionProcess clone = (JobSelectionProcess) super.clone();
            clone.setCreatedAt(null);
            clone.setUpdatedAt(null);
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
