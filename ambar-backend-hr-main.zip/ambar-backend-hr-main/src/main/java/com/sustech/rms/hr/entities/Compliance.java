package com.sustech.rms.hr.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Entity
@Table(name = "hgz_job_position_compliance")
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Compliance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "compliance_id")
    private Long id;

    @JoinColumn(name = "jobposition_id", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    private JobPositionEntity jobPositionEntity;

    private String document;
    @Column(columnDefinition = "text")
    private String notes;
    private String source;
}
