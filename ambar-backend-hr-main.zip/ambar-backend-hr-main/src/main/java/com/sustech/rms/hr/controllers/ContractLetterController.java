package com.sustech.rms.hr.controllers;

import com.itextpdf.text.DocumentException;
import com.sustech.rms.hr.dto.request.ContractLetterDto;
import com.sustech.rms.hr.dto.request.ContractLetterOnboardingDocumentDto;
import com.sustech.rms.hr.dto.request.UploadComplianceDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.services.ContractLetterService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/v1/contract-letter")
@RequiredArgsConstructor
public class ContractLetterController {
    private final ContractLetterService contractLetterService;

    @GetMapping("/application-details/{applicationId}")
    public ResponseEntity<ApiResponse> getApplicationDetails(@PathVariable Long applicationId) {
        return ResponseEntity.ok(contractLetterService.getApplicationDetails(applicationId));
    }

    @PostMapping("save")
    public ResponseEntity<ApiResponse> saveContractLetter(@RequestBody @Valid ContractLetterDto contractLetterDto) {

        return ResponseEntity.ok(contractLetterService.saveContractLetter(contractLetterDto));
    }

    @GetMapping("preview/{contractId}")
    public ResponseEntity<byte[]> preview(@PathVariable Long contractId) throws DocumentException, IOException {
        return contractLetterService.preview(contractId);
    }

    @GetMapping("download/{applicationId}")
    public ResponseEntity<ByteArrayResource> download(@PathVariable Long applicationId) throws DocumentException, IOException {
        return contractLetterService.downloadContractLetter(applicationId);
    }

    @GetMapping("view/{applicationId}")
    public ResponseEntity<byte[]> view(@PathVariable Long applicationId) throws DocumentException, IOException {
        return contractLetterService.viewContractLetter(applicationId);
    }

    @GetMapping("send/{contractId}")
    public ResponseEntity<ApiResponse> send(@PathVariable Long contractId) throws IOException, DocumentException {
        return ResponseEntity.ok(contractLetterService.send(contractId));
    }

    @GetMapping("compliance/{contractId}")
    public ResponseEntity<ApiResponse> complianceDocs(@PathVariable Long contractId) {
        return ResponseEntity.ok(contractLetterService.complianceDocs(contractId));
    }

    @PostMapping("upload-compliance")
    public ResponseEntity<ApiResponse> uploadCompliance(@RequestBody @Valid UploadComplianceDto dto){
        return ResponseEntity.ok(contractLetterService.uploadCompliance(dto));
    }

    @GetMapping("{contractId}")
    public ResponseEntity<ApiResponse> getApplicationDetailsByContractLetter(@PathVariable Long contractId){
        return ResponseEntity.ok(contractLetterService.getApplicationDetailsByContractLetter(contractId));
    }
}
