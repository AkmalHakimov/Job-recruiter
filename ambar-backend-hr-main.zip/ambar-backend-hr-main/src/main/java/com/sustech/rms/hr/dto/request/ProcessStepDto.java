package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class ProcessStepDto {
    private Long id;
    @NotNull
    private Long screeningTypeId;
    @NotEmpty
    private List<Long> userIds;
    private Long cityId;

}
