package com.sustech.rms.hr.repositories;


import com.sustech.rms.hr.entities.Compliance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComplianceRepository extends JpaRepository<Compliance, Long> {
    List<Compliance> findAllByJobPositionEntityId(Long id);
    Compliance findByJobPositionEntityIdAndNotes(Long id, String notes);
}
