package com.sustech.rms.hr.repositories.page;

import java.util.List;

import lombok.Getter;

@Getter
public class ResponsePageImpl<T> implements ResponsePage<T> {

  private List<T> elements;

  private RequestPage requestPage;

  private long totalElements;

  public ResponsePageImpl(RequestPage request, List<T> elements, long totalElements) {
    this.requestPage = request;
    this.totalElements = totalElements;
    this.elements = elements;
  }
}
