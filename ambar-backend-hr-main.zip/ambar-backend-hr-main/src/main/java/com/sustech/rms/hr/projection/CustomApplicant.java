package com.sustech.rms.hr.projection;

public interface CustomApplicant {
    Long getId();
    String getFirstName();
    String getMiddleName();
    String getSurName();
    String getTitle();
    String getEmail();
    String getMobile();
    String getPhone();
    Byte getTotalExperience();
    Long getCurrentSalary();
    Long getExpectedSalary();
}
