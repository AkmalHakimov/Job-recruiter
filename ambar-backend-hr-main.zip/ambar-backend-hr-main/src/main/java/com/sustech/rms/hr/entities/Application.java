package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.JobPositionTypeRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;


@Getter
@Setter
@Entity
@Table(name = "hgz_application", uniqueConstraints = @UniqueConstraint(columnNames = {"applicant_hgz_applicant_pk_id", "requisition_n_job_posn_pk_id"}))
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Application extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_application_pk_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "applicant_hgz_applicant_pk_id")
    private Applicant applicant;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requisition_n_job_posn_pk_id")
    private JobPositionEntity requisition;

    @ManyToOne(fetch = FetchType.LAZY)
    private JobPositionTypeRefEntity jobPositionType;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Attachment resume;

    //    @Enumerated(EnumType.STRING)
    @ManyToOne
    @JoinColumn(name = "hgz_application_status_pk_id")
    private ApplicationStatusEntity status;

    private Integer profileScore;
    private Integer reviewScore;
    private Integer missingItems;

//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "application")
//    private List<ComplianceApplication> complianceApplications = new ArrayList<>();

    @Transient
    private Boolean isAllDocsApproved;

    @Transient
    private Boolean isOfferLetterSend;

    @Transient
    private Boolean isContractLetterSend;


}
