package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.ref.JobSkillRefEntity;
import com.sustech.rms.hr.projection.JobQualProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobSkillRefRepository extends JpaRepository<JobSkillRefEntity,Long> {
    List<JobQualProjection> findAllByOrderById();
}
