package com.sustech.rms.hr.projection;

import java.sql.Timestamp;

public interface ApplicantProjection {
    Long getId();
    String getFirstName();
    String getMiddleName();
    String getSurName();
    Timestamp getUpdatedAt();
    String getEmail();
}
