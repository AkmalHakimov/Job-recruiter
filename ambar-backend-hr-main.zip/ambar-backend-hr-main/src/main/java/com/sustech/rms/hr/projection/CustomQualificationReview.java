package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomQualificationReview {
    Long getId();

    @Value("#{target.qualification?.jobQualityRef?.description}")
    String getQualificationType();

    @Value("#{target.qualification?.note}")
    String getNotes();

    Byte getMark();
}
