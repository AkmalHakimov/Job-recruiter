package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.entities.Applicant;
import com.sustech.rms.hr.entities.ref.JobRequsitionInterviewerUser;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class InterviewProjectionClass {
    private Long id;
    private Applicant applicant;
    private String applicationStatus;
    private String interviewType;
    private Long interviewTypeId;
    private List<JobRequsitionInterviewerUser> interviewers;
    private LocalDate scheduled;
    private LocalTime time;
    private String interviewStatus;
    private String note;
}
