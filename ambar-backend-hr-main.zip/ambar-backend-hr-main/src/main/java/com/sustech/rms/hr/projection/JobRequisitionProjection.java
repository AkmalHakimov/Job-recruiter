package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;

public interface JobRequisitionProjection {
    Long getId();
    LocalDate getCreatedAt();
    LocalDate getStartDate();
    LocalDate getEndDate();
    @Value("#{target.jobPositionType.description}")
    String getPositionType();
    @Value("#{target.orgDepartment.name}")
    String getDepartment();
    @Value("#{target.city!=null?target.city.name:null}")
    String getCity();
    String getStatus();
    String getPriority();
    String getProgress();


}
