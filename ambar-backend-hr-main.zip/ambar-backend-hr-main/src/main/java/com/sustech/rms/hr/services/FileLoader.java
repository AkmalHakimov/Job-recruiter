package com.sustech.rms.hr.services;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.*;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
@Component
public class FileLoader {

    private final ResourceLoader resourceLoader;

    public FileLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }
    public String readWordFileFromResources(String fileName, String breakSymbol) throws IOException {
        Resource resource = resourceLoader.getResource("classpath:" + fileName);
        try {
            StringBuilder fullDocumentContent = new StringBuilder();
            XWPFDocument document = new XWPFDocument(resource.getInputStream());
//            document.getAllPictures().forEach(picture -> {
//                String pictureType = picture.getPackagePart().getContentType();
//                byte[] imageData = picture.getData();
//                String base64ImageData = java.util.Base64.getEncoder().encodeToString(imageData);
//                fullDocumentContent.append("[Base64 Image Data: ").append(base64ImageData).append("]\n");
//            });
            document.getParagraphs().forEach(paragraph -> {
                fullDocumentContent.append(paragraph.getText()).append(breakSymbol);
            });
            return fullDocumentContent.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
    public String readTxtFileFromResources(String fileName,String breakSymbol) throws IOException {
        Resource resource = resourceLoader.getResource("classpath:" + fileName);
        StringBuilder result=new StringBuilder();
        try {
            InputStream inputStream = resource.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
                result.append(breakSymbol);
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result.toString();
    }
}
