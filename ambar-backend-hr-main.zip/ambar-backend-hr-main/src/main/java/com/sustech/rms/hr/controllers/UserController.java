package com.sustech.rms.hr.controllers;

import com.sustech.rms.hr.dto.request.CheckUserPasswordDto;
import com.sustech.rms.hr.dto.request.ResetPasswordDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.services.ActivationLinkService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1/user")
@RequiredArgsConstructor
public class UserController {
    private final ActivationLinkService activationLinkService;

    @GetMapping("{code}")
    public ResponseEntity<ApiResponse> getApplicantDetails(@PathVariable String code) {
        return ResponseEntity.ok(activationLinkService.getApplicantDetails(code));
    }

    @PostMapping("check")
    public ResponseEntity<ApiResponse> checkUserPassword(@RequestBody @Valid CheckUserPasswordDto dto) {
        return ResponseEntity.ok(activationLinkService.checkUserPassword(dto));
    }

    @PostMapping("reset-password")
    public ResponseEntity<ApiResponse> resetPassword(@RequestBody @Valid ResetPasswordDto dto) {
        return ResponseEntity.ok(activationLinkService.resetPassword(dto));
    }


}
