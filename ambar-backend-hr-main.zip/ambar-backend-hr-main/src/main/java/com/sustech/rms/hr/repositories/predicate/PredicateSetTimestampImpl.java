package com.sustech.rms.hr.repositories.predicate;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.sustech.rms.hr.constants.JobRequisitionEnums.TimestampOperatorCode;

import lombok.Getter;

public class PredicateSetTimestampImpl implements PredicateSet {

    @Getter
    private String columnCode;

    @Getter
    private Path<Long> path;

    @Getter
    private List<Predicate> predicates;

    public PredicateSetTimestampImpl(String columnCode, Root<?> root, List<String> keys) {
        this.columnCode = columnCode;
        this.predicates = new ArrayList<Predicate>();
        Iterator<String> iterator = keys.iterator();

        while (iterator.hasNext()) {
            String key = iterator.next();
            this.path = this.path == null ? root.get(key) : this.path.get(key);
        }
    }

    @Override
    public boolean addPredicate(CriteriaBuilder builder, String operatorCode, Object value) {
        Predicate predicate = null;

        try {
            LocalDate localDate = LocalDate.parse((String) value);
            Timestamp timestamp = Timestamp.valueOf(localDate.atStartOfDay());

            switch (TimestampOperatorCode.valueOf(operatorCode)) {
                case TIME_EQUAL:
                    predicate = builder.equal(this.path, timestamp);
                    this.predicates.add(predicate);
                    return true;
                case TIME_NOT_EQUAL:
                    predicate = builder.notEqual(this.path, timestamp);
                    this.predicates.add(predicate);
                    return true;
                case TIME_BEFORE:
//                    predicate = builder.lessThan(this.path, timestamp);
                    predicate = builder.lessThan(builder.function("date", Date.class, this.path), builder.literal(timestamp));
                    this.predicates.add(predicate);
                    return true;
                case TIME_AFTER:
//                    predicate = builder.greaterThan(this.path, timestamp.getTime());
                    predicate = builder.greaterThan(builder.function("date", Date.class, this.path), builder.literal(timestamp));
                    this.predicates.add(predicate);
                    return true;
                default:
                    return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Predicate[] getPredicateArray() {
        return this.predicates.toArray(new Predicate[this.predicates.size()]);
    }
}
