package com.sustech.rms.hr.projection;

public interface JobWorkAuthProjection {
    Long getId();
    String getCode();
    String getDescription();
}
