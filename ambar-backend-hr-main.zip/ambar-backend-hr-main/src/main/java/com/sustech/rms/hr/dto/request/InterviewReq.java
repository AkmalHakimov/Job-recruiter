package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.InterviewStatusEnum;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
public class InterviewReq {
    @NotNull
    private Long processRequisitionStepsId;
    @NotEmpty
    private List<Long> users;
    @NotNull
    private LocalDate date;
    private LocalTime time;
    private InterviewStatusEnum status;
    private String notes;
}
