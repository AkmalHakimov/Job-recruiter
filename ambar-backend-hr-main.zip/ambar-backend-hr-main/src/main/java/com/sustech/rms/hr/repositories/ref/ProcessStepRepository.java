package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.ProcessStep;
import com.sustech.rms.hr.projection.ProcessStepProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProcessStepRepository extends JpaRepository<ProcessStep, Long> {
    List<ProcessStepProjection> findAllByTemplateIdOrderByStage(Long templateId);
    Optional<ProcessStep> findAllByTemplateIdAndScreeningTypeIdOrderByStage(Long templateId,Long screeningTypeId);
}
