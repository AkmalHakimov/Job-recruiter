package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Applicant;
import com.sustech.rms.hr.entities.Interview;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.projection.CustomInterview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.List;

public interface InterviewRepository extends JpaRepository<Interview, Long>, InterviewCompositeRepository {
    Boolean existsByApplicationId(Long applicationId);

    List<CustomInterview> findAllByStepIdAndApplicationId(Long stepId, Long applicationId);

    Integer countAllByApplication_RequisitionAndStatus(JobPositionEntity jobPosition, String status);

    Integer countAllByApplication_RequisitionAndStatusAndStatus(JobPositionEntity jobPosition, String status, String status2);

    @Query("select count(t) from Interview t " +
            " where t.application.requisition=:jobPosition and t.attended=true and (t.note is null or t.note='') ")
    Integer countInterviewsPendingFeedback(JobPositionEntity jobPosition);

    Integer countAllByApplication_Applicant(Applicant applicant);

    Integer countAllByApplication_ApplicantAndStatusNot(Applicant applicant, String status);

    Boolean existsAllByApplication_ApplicantAndStatusNotAndScheduled(Applicant applicant, String status, Timestamp date);

    Boolean existsAllByApplication_ApplicantAndStatusNotAndScheduledAndTime(Applicant applicant, String status, Timestamp date, LocalTime time);

    @Modifying
    @Transactional
    void deleteAllByStep_JobPositionEntity_Id(Long stepId);
}
