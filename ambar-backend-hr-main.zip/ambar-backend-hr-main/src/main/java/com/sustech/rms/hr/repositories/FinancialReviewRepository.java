package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.FinancialReview;
import com.sustech.rms.hr.projection.CustomFinancialReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

public interface FinancialReviewRepository extends JpaRepository<FinancialReview, Long> {
    FinancialReview findByApplication(Application application);
    CustomFinancialReview findByApplicationId(Long application);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);
}
