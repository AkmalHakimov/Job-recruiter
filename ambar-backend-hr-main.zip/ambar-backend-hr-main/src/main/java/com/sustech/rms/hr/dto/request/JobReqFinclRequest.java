package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.CurrencyEnums;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JobReqFinclRequest {
    @NotNull
    private Long positionId;
    @NotNull
    private Long contractId;
    @NotNull
    private Boolean mandatory;
    @NotNull
    private float weight;
//    @NotNull
    private String note;
    @NotNull
    private double compositionMinRate;
    @NotNull
    private double compositionMaxRate;
    @NotNull
    private CurrencyEnums compositionCurrencyCode;
    @NotNull
    private double industryMinRate;
    @NotNull
    private double industryMaxRate;
    @NotNull
    private CurrencyEnums industryCurrencyCode;
//    @NotNull
//    private double regulatoryMinRate;
//    @NotNull
//    private double regulatoryMaxRate;
//    @NotNull
//    private CurrencyEnums regulatoryCurrencyCode;
    private Long regulatoryId;
}
