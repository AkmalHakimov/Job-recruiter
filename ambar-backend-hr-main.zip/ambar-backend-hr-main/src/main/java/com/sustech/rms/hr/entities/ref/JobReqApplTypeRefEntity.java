package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.constants.ContractTypeEnum;
import com.sustech.rms.hr.entities.ContractLetter;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_job_req_appl_type_ref")
public class JobReqApplTypeRefEntity extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_JOB_REQ_APPL_TYP_REF_PK_ID")
  private Long id;

  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  @Column(name = "V_APPL_TYP_CD")
  private String code;

  @Column(name = "V_APPL_TYP_DESC")
  @Enumerated(EnumType.STRING)
  private ContractTypeEnum description;

  public JobReqApplTypeRefEntity(String code, ContractTypeEnum description) {
    this.code = code;
    this.description = description;
  }
}
