package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.OfferLetter;
import com.sustech.rms.hr.projection.OfferLetterProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OfferLetterRepository extends JpaRepository<OfferLetter, Long> {
        Optional<OfferLetter> findByApplication(Application application);
        Optional<OfferLetterProjection> findByApplicationId(Long id);
}
