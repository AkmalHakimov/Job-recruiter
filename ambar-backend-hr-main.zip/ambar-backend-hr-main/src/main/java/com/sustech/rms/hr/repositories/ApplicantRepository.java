package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Applicant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ApplicantRepository extends JpaRepository<Applicant, Long>, ApplicantCompositeRepository {
    Optional<Applicant> findFirstByEmail(String email);
}
