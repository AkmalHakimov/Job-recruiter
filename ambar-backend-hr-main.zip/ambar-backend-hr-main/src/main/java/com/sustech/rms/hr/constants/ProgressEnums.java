package com.sustech.rms.hr.constants;

public enum ProgressEnums {
    IN_PROGRESS,
    APPROVED,
    COMPLETED,
    REJECTED
}
