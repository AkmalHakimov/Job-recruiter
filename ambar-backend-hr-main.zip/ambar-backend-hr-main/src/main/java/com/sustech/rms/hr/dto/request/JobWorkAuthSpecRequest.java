package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class JobWorkAuthSpecRequest {
    @NotNull
    private Long positionId;
    @NotNull
    private Long workAuthRefId;
    @NotNull
    private Float weight;
    @NotNull
    private Boolean mandatory;
    private String note;
}
