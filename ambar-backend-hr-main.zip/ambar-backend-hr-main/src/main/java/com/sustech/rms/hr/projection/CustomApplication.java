package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomApplication {
    Long getId();

    @Value("#{target.requisition?.id}")
    Long getRequisitionId();

    @Value("#{target.jobPositionType?.description}")
    String getJobPosition();

    @Value("#{target.jobPositionType?.id}")
    Long getJobPositionId();

    String getStatus();

    CustomApplicant getApplicant();

    CustomAttachment getResume();

    Float getProfileScore();

    Float getReviewScore();

    @Value("#{@processRequsitionStepsRepository.existsByJobPositionEntity(target.requisition)}")
    Boolean getIsSelectionProcessCompleted();
}
