package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomResumeReport {
    Integer getOccurrences();

    @Value("#{target.skill.jobSkillRef.description}")
    String getSkill();
}
