package com.sustech.rms.hr.repositories.predicate;

import com.sustech.rms.hr.constants.JobRequisitionColumnMapping;
import com.sustech.rms.hr.constants.JobRequisitionEnums.ColumnCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.InterviewColumnCode;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.Root;


@Component
public class PredicateSetFactory {

    public PredicateSet create(Root<?> root, String columnCode) {
        try {
            columnCode = columnCode.toUpperCase();
            try {
                switch (ColumnCode.valueOf(columnCode)) {
                    case PRIORITY:
                    case STATUS:
                    case PROGRESS:
                    case JOBSKILLTYPEDESC:
                    case ORGDEPTNAME:
                    case CITYNAME:
                    case CITYCOUNTRYNAME:
                    case APPLICANTNAME:
                    case APPLICANTEMAIL:
                    case APPLICANTCELL:
                        return new PredicateSetStringImpl(
                                columnCode,
                                root,
                                JobRequisitionColumnMapping.MAP.get(columnCode));
                    case ID:
                    case JOBREQID:
                    case JOBPOSITIONTYPE:
                    case ORGDEPARTMENT:
                    case CITY:
                    case APPLICANTID:
                    case REQUISITIONID:
                    case PROFILESCORE:
                    case REVIEWSCORE:
                    case MISSINGITEMS:
                    case CURRENTSALARY:
                    case EXPECTEDSALARY:
                    case TOTALEXPERIENCE:
                        return new PredicateSetIntegerImpl(
                                columnCode,
                                root,
                                JobRequisitionColumnMapping.MAP.get(columnCode));
                    case REQUESTDATE:
                    case STARTDATE:
                    case ENDDATE:
                        return new PredicateSetTimestampImpl(
                                columnCode,
                                root,
                                JobRequisitionColumnMapping.MAP.get(columnCode));
                }
            } catch (Exception e) {
            }

            try {
                switch (InterviewColumnCode.valueOf(columnCode)) {
                    case INTERVIEWSTATUS:
                    case INTERVIEWAPPLICANTSTATUS:
                    case INTERVIEWAPPLICANTNAME:
                        return new PredicateSetStringImpl(
                                columnCode,
                                root,
                                JobRequisitionColumnMapping.MAP.get(columnCode));
                    case INTERVIEWSTEPID:
                        return new PredicateSetIntegerImpl(
                                columnCode,
                                root,
                                JobRequisitionColumnMapping.MAP.get(columnCode));
                    case INTERVIEWSCHEDULED:
                        return new PredicateSetTimestampImpl(
                                columnCode,
                                root,
                                JobRequisitionColumnMapping.MAP.get(columnCode));
                    default:
                        return null;
                }
            } catch (Exception e) {
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}
