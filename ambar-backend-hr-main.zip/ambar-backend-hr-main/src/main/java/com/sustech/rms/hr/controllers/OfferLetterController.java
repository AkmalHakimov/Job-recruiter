package com.sustech.rms.hr.controllers;

import com.itextpdf.text.DocumentException;
import com.sustech.rms.hr.dto.request.OfferLetterDto;
import com.sustech.rms.hr.dto.request.UploadComplianceDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.services.OfferLetterService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/v1/offer-letter")
@RequiredArgsConstructor
public class OfferLetterController {
    private final OfferLetterService offerLetterService;

    @GetMapping("/application-details/{applicationId}")
    public ResponseEntity<ApiResponse> getApplicationDetails(@PathVariable Long applicationId) {
        return ResponseEntity.ok(offerLetterService.getApplicationDetails(applicationId));
    }

    @PostMapping("save")
    public ResponseEntity<ApiResponse> saveOfferLetter(@RequestBody @Valid OfferLetterDto offerLetterDto) {

        return ResponseEntity.ok(offerLetterService.saveOfferLetter(offerLetterDto));
    }

    @GetMapping("preview/{offerId}")
    public ResponseEntity<byte[]> preview(@PathVariable Long offerId) throws DocumentException {
        return offerLetterService.preview(offerId);
    }

    @GetMapping("download/{applicationId}")
    public ResponseEntity<ByteArrayResource> download(@PathVariable Long applicationId) throws DocumentException, IOException {
        return offerLetterService.downloadOfferLetter(applicationId);
    }

    @GetMapping("view/{applicationId}")
    public ResponseEntity<byte[]> view(@PathVariable Long applicationId) throws DocumentException {
        return offerLetterService.viewOfferLetter(applicationId);
    }

    @GetMapping("send/{offerId}")
    public ResponseEntity<ApiResponse> send(@PathVariable Long offerId) throws IOException, DocumentException {
        return ResponseEntity.ok(offerLetterService.send(offerId));
    }

    @GetMapping("compliance/{offerId}")
    public ResponseEntity<ApiResponse> complianceDocs(@PathVariable Long offerId) {
        return ResponseEntity.ok(offerLetterService.complianceDocs(offerId));
    }

    @PostMapping("upload-compliance")
    public ResponseEntity<ApiResponse> uploadCompliance(@RequestBody @Valid UploadComplianceDto dto){
        return ResponseEntity.ok(offerLetterService.uploadCompliance(dto));
    }

    @GetMapping("{offerId}")
    public ResponseEntity<ApiResponse> getApplicationDetailsByOfferLetter(@PathVariable Long offerId){
        return ResponseEntity.ok(offerLetterService.getApplicationDetailsByOfferLetter(offerId));
    }
}
