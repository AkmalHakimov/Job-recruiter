package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.constants.BCGLevelEnums;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDateTime;

public interface JobSelectionProcessProjection {
    Boolean getBcgCheck();
    BCGLevelEnums getCheckLevel();
    @Value("#{target.template.id}")
    Long getTemplateId();
    LocalDateTime getCreatedAt();
    String getCreatedBy();
}
