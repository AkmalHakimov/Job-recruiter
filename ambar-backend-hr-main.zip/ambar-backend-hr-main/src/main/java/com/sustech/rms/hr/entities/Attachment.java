package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_attachment")
@NoArgsConstructor
public class Attachment extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_attachment_pk_id")
    private Long id;
    @Column(nullable = false)
    private String originalName;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private Long fileSize;
    @Column(nullable = false)
    private String contentType;
}
