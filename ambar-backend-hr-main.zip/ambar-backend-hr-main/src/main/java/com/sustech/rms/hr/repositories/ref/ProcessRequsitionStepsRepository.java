package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.ref.ProcessRequsitionSteps;
import com.sustech.rms.hr.projection.CityProjection;
import com.sustech.rms.hr.projection.ProcessRequsitionStepsProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProcessRequsitionStepsRepository extends JpaRepository<ProcessRequsitionSteps, Long> {

    List<ProcessRequsitionStepsProjection> findAllByTemplateIdAndJobPositionEntityId(Long templateId, Long positionId);
    List<ProcessRequsitionSteps> findAllByJobPositionEntity(JobPositionEntity jobPositionEntity);
    List<ProcessRequsitionStepsProjection> findAllByJobPositionEntityId(Long positionId);

    @Query(value = "select t.cityRef from ProcessRequsitionSteps t where t.id=:id")
    CityProjection getCityRef(Long id);

    ProcessRequsitionSteps findByIdAndJobPositionEntityId(Long id, Long positionId);

    int deleteAllByJobPositionEntityId(Long positionId);

    Boolean existsByJobPositionEntity(JobPositionEntity jobPosition);

}
