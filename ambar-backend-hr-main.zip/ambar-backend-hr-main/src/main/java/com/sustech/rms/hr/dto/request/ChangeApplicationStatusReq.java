package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.ApplicationStatusEnum;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ChangeApplicationStatusReq {
    @NotNull
    private Long applicationId;
    @NotNull
    private ApplicationStatusEnum status;
}
