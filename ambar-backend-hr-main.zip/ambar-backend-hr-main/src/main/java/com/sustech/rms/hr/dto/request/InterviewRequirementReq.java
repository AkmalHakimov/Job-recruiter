package com.sustech.rms.hr.dto.request;

import lombok.Data;

@Data
public class InterviewRequirementReq {
    private Long interviewId;
    private Boolean meetsRequirement;
}
