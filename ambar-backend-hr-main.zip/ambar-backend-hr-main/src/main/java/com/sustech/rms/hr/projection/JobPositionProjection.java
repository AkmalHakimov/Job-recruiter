package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

public interface JobPositionProjection {
    @Value("#{target.industryDiscipline!=null?target.industryDiscipline.id:null}")
    Long getIndustryDisciplineId();

    @Value("#{target.orgDepartment!=null?target.orgDepartment.id:null}")
    Long getIndustryId();

    @Value("#{target.jobPositionType!=null?target.jobPositionType.id:null}")
    Long getJobPositionTypeId();

    Integer getTargetOpen();

    Integer getMinReqExperience();

    Integer getMaxReqExperience();

    LocalDate getStartDate();

    LocalDate getEndDate();

    LocalDate getTargetDate();

    String getDescription();

    @Value("#{target.priority}")
    String getPriorityEnum();

    @Value("#{@jobSelectionProcessRepository.findByJobPositionIdOrderById(target.id)}")
    Optional<JobSelectionProcessProjection> getBackgroundCheckData();

    String getProgress();

    String getStatus();

    LocalDateTime getCreatedAt();
    LocalDateTime getUpdatedAt();

    String getCreatedBy();
}
