package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.IndustryDisciplineRefEntity;
import com.sustech.rms.hr.projection.IndustryDisciplineProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IndustryDisciplineRefRepository extends JpaRepository<IndustryDisciplineRefEntity,Long> {

    List<IndustryDisciplineProjection> findAllByOrderById();
}
