package com.sustech.rms.hr.dto.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class CheckUserPasswordDto {
    @NotNull
    private String code;
    @NotNull
    private String password;
}
