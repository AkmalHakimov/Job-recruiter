package com.sustech.rms.hr.repositories.predicate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Root;

import lombok.Getter;

public class Contract {

  @Getter
  private List<PredicateSet> predicateSetList;

  @Getter
  private Root<?> root;

  @Getter
  private CriteriaBuilder builder;

  public Contract(Root<?> root, CriteriaBuilder builder) {
    this.predicateSetList = new ArrayList<PredicateSet>();
    this.builder = builder;
    this.root = root;
  }

  public PredicateSet getPredicateSet(String columnCode) {
    for (int idx = 0; idx < this.predicateSetList.size(); idx++) {
      PredicateSet ps = this.predicateSetList.get(idx);

      if (ps.getColumnCode().equals(columnCode)) {
        return ps;
      }
    }
    return null;
  }

  public boolean addPredicateSet(PredicateSet ps) {
    if (getPredicateSet(ps.getColumnCode()) == null) {
      this.predicateSetList.add(ps);
      return true;
    }
    return false;
  }
}
