package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.temporary.RegulatoryTempEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TemporaryRegulatoryRepository extends JpaRepository<RegulatoryTempEntity,Long> {

}
