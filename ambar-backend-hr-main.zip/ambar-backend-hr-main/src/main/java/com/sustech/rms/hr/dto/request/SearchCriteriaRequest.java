package com.sustech.rms.hr.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchCriteriaRequest {

  private String columnCode;

  private String operatorCode;

  private Object searchValue;

}
