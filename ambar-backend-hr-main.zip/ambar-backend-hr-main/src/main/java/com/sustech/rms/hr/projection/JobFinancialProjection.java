package com.sustech.rms.hr.projection;


import org.springframework.beans.factory.annotation.Value;

public interface JobFinancialProjection {
    Long getId();

    @Value("#{target.jobPosition.id}")
    Long getPositionId();

    @Value("#{target.jobReqApplTypeRef.id}")
    Long getContractId();

    Boolean getMandatory();

    Float getWeight();

    String getNote();

    Double getCompositionMinRate();

    Double getCompositionMaxRate();

    String getCompositionCurrencyCode();

    Double getIndustryMinRate();

    Double getIndustryMaxRate();

    String getIndustryCurrencyCode();

    Double getRegulatoryMinRate();

    Double getRegulatoryMaxRate();

    String getRegulatoryCurrencyCode();
    @Value("#{target.regulatoryTempEntity.id}")
    Long getRegulatoryId();
}
