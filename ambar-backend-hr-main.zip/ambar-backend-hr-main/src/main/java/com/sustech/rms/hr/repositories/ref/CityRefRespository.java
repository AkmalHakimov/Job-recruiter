package com.sustech.rms.hr.repositories.ref;

import org.springframework.data.repository.CrudRepository;

import com.sustech.rms.hr.entities.ref.CityRefEntity;

import java.util.List;

public interface CityRefRespository extends CrudRepository<CityRefEntity, Long> {
    List<CityRefEntity> findAllByCountryId(Long id);




}
