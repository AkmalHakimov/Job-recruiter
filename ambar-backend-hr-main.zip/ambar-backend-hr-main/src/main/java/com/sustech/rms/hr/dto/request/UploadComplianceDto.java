package com.sustech.rms.hr.dto.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Setter
@Getter
public class UploadComplianceDto {
    @NotEmpty
    private List<UploadDocDto> docs;
}
