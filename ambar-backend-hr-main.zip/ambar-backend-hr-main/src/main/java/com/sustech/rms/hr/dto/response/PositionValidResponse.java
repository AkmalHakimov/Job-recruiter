package com.sustech.rms.hr.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PositionValidResponse {
    private Boolean qualificationSuccess;
    private Boolean certificationSuccess;
    private Boolean locationSuccess;
    private Boolean workAuthSuccess;
    private Boolean financialSuccess;
    private Boolean experienceSuccess;
    private Boolean skillSuccess;
    private Boolean designationSuccess;
}
