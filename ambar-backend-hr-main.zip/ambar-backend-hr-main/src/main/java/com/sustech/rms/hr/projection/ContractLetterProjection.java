package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.constants.ContractTypeEnum;
import com.sustech.rms.hr.entities.EmployeeOnboardingDocument;
import com.sustech.rms.hr.entities.ref.JobReqApplTypeRefEntity;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.util.List;

public interface ContractLetterProjection {
    Long getId();
    LocalDate getContractCommencementDate();
    Long getHoursOfOperation();
    String getPay();
    String getLocation();
    String getGoverningLaw();
    String getIndustrialInstrument();
    LocalDate getDateOfAgreement();
    @Value("#{target.contractType.description!=null?target.contractType.description:null}")
    ContractTypeEnum getContractType();
    String getServices();
    String getNoticePeriod();
    String getName();
    Long getNumberOfDays();
    String getLiabilityRequirement();
    String getFee();
    Boolean getSent();

    List<EmployeeOnboardingDocument> getEmployeeOnboardingDocuments();
}
