package com.sustech.rms.hr.projection;

public interface JobRequisitionSummaryProjection {
    String getHiringManager();
}
