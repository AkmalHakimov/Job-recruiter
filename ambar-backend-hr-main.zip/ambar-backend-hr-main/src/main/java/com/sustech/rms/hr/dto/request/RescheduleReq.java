package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
public class RescheduleReq {
    @NotEmpty
    private List<Long> interviewIds;
    private LocalDate scheduled;
    private LocalTime time;
}
