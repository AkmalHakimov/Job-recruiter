package com.sustech.rms.hr.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobCertSpecRequest {
    @NotNull
    private Long jobCertRefId;
    @NotNull
    private Long jobPositionId;
    @NotNull
    private Boolean mandatory;
    @NotNull
    private float weight;
    private String note;
    @NotNull
    private Boolean complianceDocument;
}
