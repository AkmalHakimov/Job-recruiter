package com.sustech.rms.hr.dto.response;

import com.sustech.rms.hr.projection.JobSelectionProcessProjection;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Optional;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobSelectionProcessDto<T> {
    private List<T> processSteps;
    private Optional<JobSelectionProcessProjection> jobSelectionProcess;
}
