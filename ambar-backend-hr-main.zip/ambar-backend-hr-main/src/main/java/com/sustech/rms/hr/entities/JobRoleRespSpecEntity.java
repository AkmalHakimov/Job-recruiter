package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.JobRoleRespRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_role_resp_spec")
@NoArgsConstructor
public class JobRoleRespSpecEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_ROLE_RESP_SPEC_PK_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    private JobPositionEntity jobPosition;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_ROLE_RESP_REF_PK_ID")
    private JobRoleRespRefEntity jobRoleRespRef;

    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "V_MAND_JOB_RESP_IND")
    private Boolean mandatory;

    @Column(name = "D_WGHT_NUM")
    private float weight;

    @Column(name = "V_JOB_ROLE_RESP_NOTE_TXT")
    private String note;

    public JobRoleRespSpecEntity(JobPositionEntity jobPosition, JobRoleRespRefEntity jobRoleRespRef, Boolean mandatory, float weight, String note) {
        this.jobPosition = jobPosition;
        this.jobRoleRespRef = jobRoleRespRef;
        this.mandatory = mandatory;
        this.weight = weight;
        this.note = note;
    }

    public JobRoleRespSpecEntity setNewValues(JobPositionEntity jobPosition) {
        this.id = null;
        this.jobPosition = jobPosition;
        return this;
    }

    @Override
    public JobRoleRespSpecEntity clone() {
        try {
            JobRoleRespSpecEntity clone = (JobRoleRespSpecEntity) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
