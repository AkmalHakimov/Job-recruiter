package com.sustech.rms.hr.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Map;

@Service
public class EmailSenderService {
    @Autowired
    private JavaMailSender mailSender;
    @Value("${email_sender}")
    private String emailSender;
    @Autowired
    private ResourceLoader resourceLoader;

    public void sendSimpleEmail(String toEmail,
                                String subject,
                                String body
    ) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(emailSender);
        message.setTo(toEmail);
        message.setText(body);
        message.setSubject(subject);
        try {
            mailSender.send(message);
            System.out.println("Mail Send...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean sendEmailWithFile(String to, String sub, String msgBody, Map<String, byte[]> files) throws IOException {
        MimeMessage message = mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setFrom(emailSender);
            helper.setTo(to);
            helper.setSubject(sub);
            msgBody = msgBody.replaceAll("\n", "<br>");
            helper.setText(msgBody, true);
            for (String fileName : files.keySet()) {
                helper.addAttachment(fileName, new ByteArrayResource(files.get(fileName)));
            }
            mailSender.send(message);
            return true;
        } catch (MessagingException e) {
            return false;
        }
    }
    private static byte[] convertImageToByteArray(BufferedImage image) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos); // You can change "jpg" to the desired image format
        baos.flush();
        byte[] imageBytes = baos.toByteArray();
        baos.close();
        return imageBytes;
    }


}

