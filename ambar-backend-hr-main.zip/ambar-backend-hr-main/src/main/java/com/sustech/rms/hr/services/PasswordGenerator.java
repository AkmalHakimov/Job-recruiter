package com.sustech.rms.hr.services;

import java.util.Random;

public class PasswordGenerator {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final String NUMBERS = "0123456789";
    private static final String SPECIAL_CHARACTERS = "!@#$%*()_-+=?";

    public static String generateRandomPassword(int length) {
        StringBuilder password = new StringBuilder();
        Random random = new Random();

        // Add at least one character from each category
        password.append(getRandomCharacter(CHARACTERS, random));
        password.append(getRandomCharacter(NUMBERS, random));
        password.append(getRandomCharacter(SPECIAL_CHARACTERS, random));

        // Generate remaining characters
        for (int i = 0; i < length - 3; i++) {
            String allCharacters = CHARACTERS + NUMBERS + SPECIAL_CHARACTERS;
            password.append(getRandomCharacter(allCharacters, random));
        }

        // Shuffle the password to make it random
        for (int i = 0; i < password.length(); i++) {
            int randomIndex = random.nextInt(password.length());
            char temp = password.charAt(i);
            password.setCharAt(i, password.charAt(randomIndex));
            password.setCharAt(randomIndex, temp);
        }

        return password.toString();
    }

    private static char getRandomCharacter(String characters, Random random) {
        int randomIndex = random.nextInt(characters.length());
        return characters.charAt(randomIndex);
    }
}
