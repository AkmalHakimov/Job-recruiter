package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.constants.ComplianceApplicationStatus;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ComplianceApplicationReq {
    private Long fileId;
    private ComplianceApplicationStatus status;
    private LocalDate dueDate;
}
