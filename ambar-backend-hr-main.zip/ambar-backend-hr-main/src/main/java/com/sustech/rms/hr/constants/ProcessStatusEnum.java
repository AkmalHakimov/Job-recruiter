package com.sustech.rms.hr.constants;

public enum ProcessStatusEnum {

    Active,
    InActive,



}
