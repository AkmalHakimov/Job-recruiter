package com.sustech.rms.hr.repositories.page;

public interface RequestPage {

  public int getPageNumber();

  public int getPageLimit();

  public int getStartingIndex();

}
