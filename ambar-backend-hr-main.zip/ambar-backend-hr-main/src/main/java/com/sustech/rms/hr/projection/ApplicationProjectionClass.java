package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.entities.Applicant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class ApplicationProjectionClass {
    private Long id;
    private String status;
    private Applicant applicant;
    private Integer allInterviewsCount;
    private Integer completedInterviewsCount;
    private Integer allCompliances;
    private Integer approvedCompliances;
}
