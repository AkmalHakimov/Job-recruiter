package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

import java.util.Optional;

public interface CustomApplication1 {
    Long getId();
    @Value("#{target.applicant.id}")
    Long getApplicantId();
    @Value("#{target.applicant.firstName}")
    String getApplicantName();
    @Value("#{target.applicant.email}")
    String getApplicantEmail();
    @Value("#{target.applicant.phone}")
    String getApplicantPhone();
    @Value("#{target.requisition.orgDepartment.name}")
    String getDepartment();
    @Value("#{target.requisition.jobPositionType.description}")
    String getJobTitle();
    @Value("#{target.requisition.city.name}")
    String getCity();
    @Value("#{target.requisition.city.country.name}")
    String getCountry();
    @Value("#{@jobRequisitionSummaryRepository.findByRequisitionIdOrderByIdAsc(target.requisition.id)}")
    Optional<JobRequisitionSummaryProjection> getRequisitionSummary();
    @Value("#{@offerLetterRepository.findByApplicationId(target.id)}")
    Optional<OfferLetterProjection> getOfferLetter();
}
