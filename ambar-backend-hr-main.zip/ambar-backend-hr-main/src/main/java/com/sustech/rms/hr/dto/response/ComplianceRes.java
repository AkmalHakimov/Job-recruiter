package com.sustech.rms.hr.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class ComplianceRes {
    private Long id;

    private String document;

    private String notes;

    private String source;
}
