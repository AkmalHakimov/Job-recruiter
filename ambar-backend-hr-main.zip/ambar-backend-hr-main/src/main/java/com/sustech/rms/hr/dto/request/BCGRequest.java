package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class BCGRequest {

    @NotNull
    private Long templateId;

    @NotNull
    private Long positionId;

    @NotNull
    private Boolean bcgCheck;

    @NotNull
    private String checkLevel;

    @NotEmpty
    private List<ProcessStepDto> stepDtos;

}
