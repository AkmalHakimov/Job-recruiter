package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomQualification {
    Long getId();

    @Value("#{target.jobQualityRef?.description}")
    String getDocument();

    @Value("#{target.note}")
    String getNotes();

    default String getSource() {
        return "Qualification";
    }
}
