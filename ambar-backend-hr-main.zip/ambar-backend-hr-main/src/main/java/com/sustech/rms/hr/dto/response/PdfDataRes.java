package com.sustech.rms.hr.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class PdfDataRes {
    private String positionTitle;
    private String city;
    private Long positionId;
    private Integer minExperience;
    private Integer maxExperience;
    private List<String> qualifications;
    private List<String> designations;
    private String jobDescription;
    private List<String> skills;
    private List<String> authorizations;
    private Double compensationFrom;
    private Double compensationTo;
    private String contractType;
    private List<String> responsibilities;
}
