package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.WorkAuthReview;
import com.sustech.rms.hr.projection.CustomWorkAuthReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface WorkAuthReviewRepository extends JpaRepository<WorkAuthReview, Long> {
    List<WorkAuthReview> findAllByApplication(Application application);
    List<CustomWorkAuthReview> findAllByApplicationId(Long application);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);

    @Transactional
    @Modifying
    void deleteAllByWorkAuthId(Long id);
}
