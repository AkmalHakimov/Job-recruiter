package com.sustech.rms.hr.dto.request;

import com.sustech.rms.hr.entities.EmployeeOnboardingDocument;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class ContractLetterOnboardingDocumentDto {
    private ContractLetterDto contractLetter;
    private List<EmployeeOnboardingDocument> employeeOnboardingDocuments;

}
