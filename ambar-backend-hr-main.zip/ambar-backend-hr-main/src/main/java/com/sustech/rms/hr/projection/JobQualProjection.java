package com.sustech.rms.hr.projection;

public interface JobQualProjection {
    Long getId();
    String getCode();
    String getDescription();
}
