package com.sustech.rms.hr.projection;


import org.springframework.beans.factory.annotation.Value;

public interface JobExProjection {
    Long getId();

    @Value("#{target.jobPosition.id}")
    Long getPositionId();

    @Value("#{target.industryRef}")
    DepartmentRefProjection getIndustry();

    @Value("#{target.industryDiscipline}")
    IndustryDisciplineProjection getIndustryDiscipline();

    @Value("#{target.jobPositionTypeRef}")
    JobCertREfProjection getJobPositionTypeId();

    Boolean getMandatory();

    Float getWeight();
}
