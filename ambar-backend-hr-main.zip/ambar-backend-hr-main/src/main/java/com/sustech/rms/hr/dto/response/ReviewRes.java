package com.sustech.rms.hr.dto.response;

import com.sustech.rms.hr.projection.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class ReviewRes {
    private List<CustomQualificationReview> qualificationReviews;
    private List<CustomCertificationReview> certificationReviews;
    private List<CustomWorkAuthReview> workAuthReviews;
    private CustomLocationReview locationReview;
    private CustomFinancialReview financialReview;
    private List<CustomExperienceReview> experienceReviews;
    private List<CustomSkillReview> skillReviews;
}
