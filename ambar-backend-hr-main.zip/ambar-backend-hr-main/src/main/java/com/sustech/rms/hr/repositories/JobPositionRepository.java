package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.projection.JobPositionProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface JobPositionRepository extends JpaRepository<JobPositionEntity, Long> {

    @Query("select t from JobPositionEntity t where t.id=:positionId")
    JobPositionProjection findPosition(Long positionId);


}
