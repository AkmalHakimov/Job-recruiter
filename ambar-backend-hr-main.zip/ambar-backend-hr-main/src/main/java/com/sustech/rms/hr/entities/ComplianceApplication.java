package com.sustech.rms.hr.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "hgz_compliance_application")
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ComplianceApplication {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "compliance_application_id")
    private Long id;
    //    private String document;
//    @Column(columnDefinition = "text")
//    private String details;
//    private String source;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "compliance_id")
    private Compliance compliance;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "certification_id")
    private JobRequisitionCertificateSpecEntity certification;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "qualification_id")
    private JobRequisitionQualifSpecEntity qualification;
    //    @Enumerated(EnumType.STRING)
    private String status;
    @Column(name = "due_date")
    private LocalDate dueDate;
    @Column(name = "submitted_on")
    private LocalDate submittedOn;
    @Column(name = "approved_on")
    private LocalDate approvedOn;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_id")
    private Attachment file;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    private Application application;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applicant_file")
    private Attachment applicantFile;
}
