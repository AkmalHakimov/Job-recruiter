package com.sustech.rms.hr.services;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import com.sustech.rms.hr.constants.EmailTemplateTypeEnum;
import com.sustech.rms.hr.dto.request.OfferLetterDto;
import com.sustech.rms.hr.dto.request.UploadComplianceDto;
import com.sustech.rms.hr.dto.request.UploadDocDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.entities.*;
import com.sustech.rms.hr.projection.CustomComplianceApplication;
import com.sustech.rms.hr.projection.JobRequisitionSummaryProjection;
import com.sustech.rms.hr.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

import com.itextpdf.text.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class OfferLetterService {
    private final AttachmentRepository attachmentRepository;
    private final ApplicationRepository applicationRepository;
    private final OfferLetterRepository offerLetterRepository;
    private final FileLoader fileLoader;
    private final JobRequisitionSummaryRepository jobRequisitionSummaryRepository;
    @Value("${domain.url}")
    private String domainUrl;
    private final ActivationLinkRepository activationLinkRepository;
    private final EmailSenderService emailSenderService;
    private final ComplianceApplicationRepository complianceApplicationRepository;
    private final ResourceLoader resourceLoader;
    private final EmailTemplateRepository emailTemplateRepository;
    @Value("${UPLOAD_DIR}")
    private String UPLOAD_DIR;

    public ApiResponse getApplicationDetails(Long applicationId) {
        return ApiResponse.builder()
                .success(true)
                .data(applicationRepository.findByIdOrderByIdAsc(applicationId))
                .build();
    }

    public ApiResponse saveOfferLetter(OfferLetterDto offerLetterDto) {
        Application application = applicationRepository.getReferenceById(offerLetterDto.getApplicationId());
        Optional<OfferLetter> offerLetterOptional = offerLetterRepository.findByApplication(application);
        OfferLetter offerLetter;
        if (offerLetterOptional.isPresent()) {
            offerLetter = offerLetterOptional.get();
            offerLetter.setOfferCreationDate(offerLetterDto.getOfferCreationDate());
            offerLetter.setOfferAcceptanceDate(offerLetterDto.getOfferAcceptanceDate());
            offerLetter.setOfferDueDate(offerLetterDto.getOfferDueDate());
            offerLetter.setDateOfJoining(offerLetterDto.getDateOfJoining());
            offerLetter.setPayFrequency(offerLetterDto.getPayFrequency());
            offerLetter.setSalaryType(offerLetterDto.getSalaryType());
            offerLetter.setSalaryWageRate(offerLetterDto.getSalaryWageRate());
            offerLetter.setCurrencyType(offerLetterDto.getCurrencyType());
        } else {
            offerLetter = OfferLetter.builder()
                    .application(application)
                    .offerCreationDate(offerLetterDto.getOfferCreationDate())
                    .offerAcceptanceDate(offerLetterDto.getOfferAcceptanceDate())
                    .offerDueDate(offerLetterDto.getOfferDueDate())
                    .dateOfJoining(offerLetterDto.getDateOfJoining())
                    .payFrequency(offerLetterDto.getPayFrequency())
                    .salaryType(offerLetterDto.getSalaryType())
                    .salaryWageRate(offerLetterDto.getSalaryWageRate())
                    .currencyType(offerLetterDto.getCurrencyType())
                    .build();
        }
        offerLetterRepository.save(offerLetter);
        return ApiResponse.builder()
                .success(true)
                .message("saved")
                .data(offerLetter.getId())
                .build();
    }

    public ResponseEntity<byte[]> preview(Long offerId) throws DocumentException {
        String offerText = generateOfferLetter("newOfferLetter.docx", offerId, "\n");
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, out);
        document.open();
        document.add(new Paragraph(offerText));
        document.close();
        ByteArrayResource resource = new ByteArrayResource(out.toByteArray());
        return ResponseEntity.ok(generatePdfFile(offerText));

    }

    public byte[] generatePdfFile(String text) throws DocumentException {
        Document document = new Document();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, out);
        document.open();
        Resource loaderResource = resourceLoader.getResource("classpath:" + "logo.png");
        Image image = null;
        try (InputStream inputStream = loaderResource.getInputStream()) {
            byte[] imageBytes = IOUtils.toByteArray(inputStream);
            image = Image.getInstance(imageBytes);
        } catch (IOException | BadElementException e) {
            e.printStackTrace();
        }
        image.scaleToFit(100, 100);
        Rectangle pageSize = document.getPageSize();

        float xPosition = pageSize.getWidth() - image.getScaledWidth() - 20;
        float yPosition = pageSize.getHeight() - image.getScaledHeight() - 20;
        image.setAbsolutePosition(xPosition, yPosition);
        document.add(image);

        document.add(new Paragraph(text));
        document.close();
        return out.toByteArray();
    }

    public ResponseEntity<ByteArrayResource> downloadOfferLetter(Long applicationId) throws DocumentException, IOException {
        System.out.println(applicationId);
        System.out.println(applicationRepository.getReferenceById(applicationId));
        OfferLetter offerLetter = offerLetterRepository.findByApplication(applicationRepository.getReferenceById(applicationId))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "application not found"));

        String offerText = generateOfferLetter("newOfferLetter.docx", offerLetter.getId(), "\n");
        byte[] bytes = generatePdfFile(offerText);
        ByteArrayResource resource = new ByteArrayResource(bytes);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .contentLength(resource.contentLength())
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment()
                                .filename("offerLetter.pdf")
                                .build().toString())
                .body(resource);
    }


    public ResponseEntity<byte[]> viewOfferLetter(Long applicationId) throws DocumentException {
        OfferLetter offerLetter = offerLetterRepository.findByApplication(applicationRepository.getReferenceById(applicationId)).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "application not found"));
        String offerText = generateOfferLetter("newOfferLetter.docx", offerLetter.getId(), "\n");
        return ResponseEntity.ok(generatePdfFile(offerText));
    }

    public ApiResponse send(Long offerId) throws IOException, DocumentException {
        String offerTxt = generateOfferLetter("offerLetter.txt", offerId, "\n");
        OfferLetter offerLetter = offerLetterRepository.getReferenceById(offerId);
        Applicant applicant = offerLetter.getApplication().getApplicant();
        List<ComplianceApplication> compliancesApplications = complianceApplicationRepository.findAllByApplication(offerLetter.getApplication());
        Map<String, byte[]> files = new HashMap<>();
        for (ComplianceApplication compliancesApplication : compliancesApplications) {
            Attachment attachment = compliancesApplication.getFile();
            if (attachment != null) {
                String resumeOriginalName = attachment.getOriginalName();
                File file = new File(UPLOAD_DIR + "/" + attachment.getName());
                byte[] bytes;
                try {
                    bytes = Files.readAllBytes(file.toPath());
                } catch (IOException e) {
                    log.error(e.getMessage());
                    throw new RuntimeException(e.getMessage());
                }
                files.put(resumeOriginalName, bytes);
            }
        }
        String contractText = generateOfferLetter("newOfferLetter.docx", offerLetter.getId(), "\n");
        files.put("offerLetter.pdf", generatePdfFile(contractText));
        boolean emailSendResult = emailSenderService.sendEmailWithFile(applicant.getEmail(), emailTemplateRepository.findByEmailType(EmailTemplateTypeEnum.JOB_OFFER_NOTIFICATION).orElseThrow().getEmailSubject(), offerTxt, files);
        if (emailSendResult) {
            offerLetter.setSent(true);
            offerLetterRepository.save(offerLetter);
        }
        return ApiResponse.builder()
                .success(emailSendResult)
                .build();
    }

    private String generateOfferLetter(String filename, Long offerId, String breakSymbol) {
        OfferLetter offerLetter = offerLetterRepository.getReferenceById(offerId);
        String offerTxt = "";
        try {
            Optional<ActivationLink> activationLinkOptional = activationLinkRepository.findByApplication(offerLetter.getApplication());
            ActivationLink activationLink = activationLinkOptional.orElseGet(() -> createActivationLink(offerLetter));
            Optional<JobRequisitionSummaryProjection> jobRequisitionSummaryOptional = jobRequisitionSummaryRepository.findByRequisitionIdOrderByIdAsc(offerLetter.getApplication().getRequisition().getId());
            offerTxt = filename.equals("offerLetter.txt") ? emailTemplateRepository.findByEmailType(EmailTemplateTypeEnum.JOB_OFFER_NOTIFICATION).orElseThrow().getEmailBody() : fileLoader.readWordFileFromResources(filename, breakSymbol);
            offerTxt = offerTxt.replaceAll("<ApplicantName>", offerLetter.getApplication().getApplicant().getFirstName() + " " + offerLetter.getApplication().getApplicant().getMiddleName() + " " + offerLetter.getApplication().getApplicant().getSurName())
                    .replaceAll("<JobPosition>", offerLetter.getApplication().getRequisition().getJobPositionType().getDescription())
                    .replaceAll("<Location,Country>", offerLetter.getApplication().getRequisition().getCity().getName() + ", " + offerLetter.getApplication().getRequisition().getCity().getCountry().getName())
                    .replaceAll("<DateOfJoining>", offerLetter.getDateOfJoining().toString())
                    .replaceAll("<OfferAcceptanceDate>", offerLetter.getOfferAcceptanceDate().toString())
                    .replaceAll("<Link>", domainUrl + "/offer-letter?code=" + activationLink.getCode() + "&offerId=" + offerId)
                    .replaceAll("<ApplicantEmail>", offerLetter.getApplication().getApplicant().getEmail())
                    .replaceAll("null", "")
                    .replace("<PWD>", activationLink.getPassword());

            if (jobRequisitionSummaryOptional.isPresent()) {
                offerTxt = offerTxt.replaceAll("<HiringManagerName>", jobRequisitionSummaryOptional.get().getHiringManager());
            }
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
        System.out.println(offerTxt);
        return offerTxt;
    }

    private ActivationLink createActivationLink(OfferLetter offerLetter) {
        String password = PasswordGenerator.generateRandomPassword(6);
        ActivationLink activationLink = ActivationLink.builder()
                .application(offerLetter.getApplication())
                .password(password)
                .build();
        activationLinkRepository.save(activationLink);
        return activationLink;
    }

    public ApiResponse complianceDocs(Long offerId) {
        OfferLetter offerLetter = offerLetterRepository.getReferenceById(offerId);
        Applicant applicant = offerLetter.getApplication().getApplicant();
        activationLinkRepository.findByApplicationAndActiveIsTrue(offerLetter.getApplication()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not active"));
        List<CustomComplianceApplication> complianceApplication = complianceApplicationRepository.findAllByApplicationId(offerLetter.getApplication().getId());
        List<CustomComplianceApplication> complianceApplications = new ArrayList<>();
        for (CustomComplianceApplication complianceApplicatio : complianceApplication) {
            if (!complianceApplicatio.getCompliance().getNotes().equals("signedcontractletteronlyforonlyapp")){
                complianceApplications.add(complianceApplicatio);
            }
        }
        return ApiResponse.builder()
                .data(complianceApplications)
                .build();
    }

    @Transactional
    public ApiResponse uploadCompliance(UploadComplianceDto dto) {
        for (UploadDocDto doc : dto.getDocs()) {
            var complianceApplication = complianceApplicationRepository.getReferenceById(doc.getComplianceId());
            complianceApplication.setApplicantFile(attachmentRepository.getReferenceById(doc.getFileId()));
            complianceApplicationRepository.save(complianceApplication);
        }
        return ApiResponse.builder().build();
    }

    public ApiResponse getApplicationDetailsByOfferLetter(Long offerId) {
        return getApplicationDetails(offerLetterRepository.getReferenceById(offerId).getApplication().getId());
    }
}
