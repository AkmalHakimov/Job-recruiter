package com.sustech.rms.hr.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Paging {

  private int page;

  private int pageLimit;

  private int pageSize;

  private long total;

}
