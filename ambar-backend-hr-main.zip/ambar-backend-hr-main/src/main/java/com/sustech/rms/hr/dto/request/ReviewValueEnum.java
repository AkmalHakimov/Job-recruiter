package com.sustech.rms.hr.dto.request;

public enum ReviewValueEnum {
    YES,
    NO,
    PARTIAL
}
