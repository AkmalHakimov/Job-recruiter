package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_industry_ref")
@NoArgsConstructor
public class IndustryRefEntity extends AbstractEntity {

  public IndustryRefEntity(String code, String description) {
    this.code = code;
    this.description = description;
  }
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_INDSTRY_REF_PK_ID")
  private Long id;



  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  @Column(name = "V_INDSTRY_TYP_CD")
  private String code;

  @Column(name = "V_INDSTRY_TYP_DESC")
  private String description;

}
