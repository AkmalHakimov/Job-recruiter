package com.sustech.rms.hr.controllers;

import com.sustech.rms.hr.dto.request.ChangeStatusDocDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.services.ComplianceApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1/compliance-application")
@RequiredArgsConstructor
public class ComplianceApplicationController {
    private final ComplianceApplicationService complianceApplicationService;

    @PostMapping("change-status")
    public ResponseEntity<ApiResponse> changeStatus(@RequestBody @Valid ChangeStatusDocDto dto){
        return ResponseEntity.ok(complianceApplicationService.changeStatus(dto));
    }
}
