package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

import java.util.List;

public interface ProcessRequsitionStepsProjection {
    Long getId();

    @Value("#{target.screeningType.id}")
    Long getScreeningTypeId();

    @Value("#{target.screeningType.name}")
    String getScreeningTypeName();

    String getStatus();

    List<InterviewUserProjection> getInterviewUsers();

    CityProjection getCityRef();

}
