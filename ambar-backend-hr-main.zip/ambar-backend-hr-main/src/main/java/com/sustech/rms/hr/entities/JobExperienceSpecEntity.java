package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.ref.IndustryDisciplineRefEntity;
import com.sustech.rms.hr.entities.ref.JobPositionTypeRefEntity;
import com.sustech.rms.hr.entities.ref.OrgDepartmentRefEntity;
import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "hgz_job_req_experience_spec")
@NoArgsConstructor
public class JobExperienceSpecEntity extends AbstractEntity implements Cloneable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_JOB_REQ_SKILL_SPEC_PK_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_POSN_PK_ID")
    private JobPositionEntity jobPosition;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_INDSTRY_REF_PK_ID")
    private OrgDepartmentRefEntity industryRef;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_INDSTRY_DSCPL_REF_PK_ID")
    private IndustryDisciplineRefEntity industryDiscipline;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "N_JOB_PSTN_REF_PK_ID")
    private JobPositionTypeRefEntity jobPositionTypeRef;

    @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
    private String systemCode;

    @Column(name = "V_MAND_SKILL_IND")
    private Boolean mandatory;

    @Column(name = "D_WGHT_NUM")
    private Float weight;

    public JobExperienceSpecEntity(JobPositionEntity jobPosition, OrgDepartmentRefEntity industryRef, IndustryDisciplineRefEntity industryDiscipline, JobPositionTypeRefEntity jobPositionTypeRef, Boolean mandatory, float weight) {
        this.jobPosition = jobPosition;
        this.industryRef = industryRef;
        this.industryDiscipline = industryDiscipline;
        this.jobPositionTypeRef = jobPositionTypeRef;
        this.mandatory = mandatory;
        this.weight = weight;
    }

    public JobExperienceSpecEntity setNewValues(JobPositionEntity jobPosition) {
        this.id = null;
        this.jobPosition = jobPosition;
        return this;
    }

    @Override
    public JobExperienceSpecEntity clone() {
        try {
            JobExperienceSpecEntity clone = (JobExperienceSpecEntity) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
