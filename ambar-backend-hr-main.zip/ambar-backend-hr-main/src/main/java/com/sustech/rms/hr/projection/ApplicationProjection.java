package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface ApplicationProjection {
    Long getId();

    String getStatus();

    ApplicantProjection getApplicant();

    @Value("#{@interviewRepository.countAllByApplication_Applicant(target.applicant)}")
    Integer getAllInterviewsCount();

    @Value("#{@interviewRepository.countAllByApplication_ApplicantAndStatusNot(target.applicant,'COMPLETE')}")
    Integer getCompletedInterviewsCount();

    @Value("#{@complianceApplicationRepository.countAllByApplication_Requisition(target.requisition)}")
    Integer getAllCompliances();

    @Value("#{@complianceApplicationRepository.countAllByApplication_RequisitionAndStatus(target.requisition,'APPROVED')}")
    Integer getApprovedCompliances();
}
