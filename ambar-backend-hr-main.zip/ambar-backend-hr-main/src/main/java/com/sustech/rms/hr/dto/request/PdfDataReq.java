package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class PdfDataReq {
    @NotEmpty
    private List<Long> ids;
}
