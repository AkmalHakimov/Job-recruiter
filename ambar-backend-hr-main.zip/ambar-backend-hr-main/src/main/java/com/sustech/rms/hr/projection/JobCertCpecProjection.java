package com.sustech.rms.hr.projection;

public interface JobCertCpecProjection {
    Long getId();
    Float getWeight();
    Boolean getMandatory();
    JobCertREfProjection getJobCertificateRef();
    String getNote();
    Boolean getComplianceDocument();
}

