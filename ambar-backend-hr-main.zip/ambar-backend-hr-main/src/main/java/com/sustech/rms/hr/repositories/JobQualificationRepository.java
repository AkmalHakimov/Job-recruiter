package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.JobRequisitionQualifSpecEntity;
import com.sustech.rms.hr.projection.JobQualSpecProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface JobQualificationRepository extends JpaRepository<JobRequisitionQualifSpecEntity, Long> {

    Page<JobQualSpecProjection> findAllByJobPositionId(Long positionId, Pageable pageable);
    List<JobRequisitionQualifSpecEntity> findAllByJobPosition(JobPositionEntity jobPosition);

    Optional<JobRequisitionQualifSpecEntity> getFirstByJobPositionId(Long positionId);

    List<JobRequisitionQualifSpecEntity> findAllByJobPositionIdAndComplianceDocumentIsTrue(Long positionId);
}
