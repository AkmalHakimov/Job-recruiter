package com.sustech.rms.hr.projection;

public interface CustomAttachment {
    Long getId();
    String getOriginalName();
}
