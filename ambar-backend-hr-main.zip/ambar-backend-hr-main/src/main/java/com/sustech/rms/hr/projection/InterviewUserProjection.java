package com.sustech.rms.hr.projection;

public interface InterviewUserProjection {

    Long getId();

    String getFullName();

    String getEmail();

}
