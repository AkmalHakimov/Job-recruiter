package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class AssignInterviewerReq {
    @NotEmpty
    private List<Long> interviewIds;
    @NotEmpty
    private List<Long> users;
}
