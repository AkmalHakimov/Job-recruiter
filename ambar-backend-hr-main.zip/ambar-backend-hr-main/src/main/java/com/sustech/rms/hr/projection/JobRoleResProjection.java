package com.sustech.rms.hr.projection;


import org.springframework.beans.factory.annotation.Value;

public interface JobRoleResProjection {
    Long getId();

    @Value("#{target.jobRoleRespRef}")
    JobCertREfProjection getRoleRes();

    @Value("#{target.jobRoleRespRef.jobDesignationType}")
    JobCertREfProjection getDesignation();

    @Value("#{target.jobPosition.id}")
    Long getJobPositionId();

    Boolean getMandatory();

    Float getWeight();
    String getNote();
}
