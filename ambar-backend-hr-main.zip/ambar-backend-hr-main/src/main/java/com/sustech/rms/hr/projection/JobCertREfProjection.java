package com.sustech.rms.hr.projection;

public interface JobCertREfProjection {
    Long getId();

    String getCode();

    String getDescription();
}
