package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomCertificationReview {
    Long getId();

    @Value("#{target.certificate?.jobCertificateRef?.description}")
    String getCertificationType();

    @Value("#{target.certificate?.note}")
    String getNotes();

    Byte getMark();
}
