package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class AddCandidateReq {
    @NotNull
    private Long requisitionId;
    @NotNull
    private Long applicationId;
}
