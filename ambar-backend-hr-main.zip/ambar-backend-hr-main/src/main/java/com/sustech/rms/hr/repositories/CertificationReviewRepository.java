package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.CertificationReview;
import com.sustech.rms.hr.projection.CustomCertificationReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CertificationReviewRepository extends JpaRepository<CertificationReview, Long> {
    List<CertificationReview> findAllByApplication(Application application);
    List<CustomCertificationReview> findAllByApplicationId(Long applicationId);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);

    @Transactional
    @Modifying
    void deleteAllByCertificateId(Long id);

}
