package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.SkillReview;
import com.sustech.rms.hr.projection.CustomSkillReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface SkillReviewRepository extends JpaRepository<SkillReview, Long> {
    List<SkillReview> findAllByApplication(Application application);

    @Transactional
    @Modifying
    void deleteAllBySkillId(Long skillId);

    List<CustomSkillReview> findAllByApplicationId(Long application);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);
}
