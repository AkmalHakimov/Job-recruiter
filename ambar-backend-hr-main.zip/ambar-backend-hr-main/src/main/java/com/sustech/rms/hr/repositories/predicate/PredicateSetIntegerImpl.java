package com.sustech.rms.hr.repositories.predicate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.sustech.rms.hr.constants.JobRequisitionEnums.NumberOperatorCode;

import lombok.Getter;

public class PredicateSetIntegerImpl implements PredicateSet {

  @Getter
  private String columnCode;

  @Getter
  private Path<Integer> path;

  @Getter
  private List<Predicate> predicates;

  public PredicateSetIntegerImpl(String columnCode, Root<?> root, List<String> keys) {
    this.columnCode = columnCode;
    this.predicates = new ArrayList<Predicate>();
    Iterator<String> iterator = keys.iterator();

    while (iterator.hasNext()) {
      String key = iterator.next();
      this.path = this.path == null ? root.get(key) : this.path.get(key);
    }
  }

  @Override
  public boolean addPredicate(CriteriaBuilder builder, String operatorCode, Object value) {
    Predicate predicate = null;

    try {
      switch (NumberOperatorCode.valueOf(operatorCode)) {
        case NUM_EQUAL:
          predicate = builder.equal(this.path, Integer.parseInt((String) value));
          this.predicates.add(predicate);
          return true;
        case NUM_NOT_EQUAL:
          predicate = builder.notEqual(this.path, Integer.parseInt((String) value));
          this.predicates.add(predicate);
          return true;
        case NUM_GREATER:
          predicate = builder.gt(this.path, Integer.parseInt((String) value));
          this.predicates.add(predicate);
          return true;
        case NUM_GREATER_EQUAL:
          predicate = builder.ge(this.path, Integer.parseInt((String) value));
          this.predicates.add(predicate);
          return true;
        case NUM_LESSER:
          predicate = builder.lt(this.path, Integer.parseInt((String) value));
          this.predicates.add(predicate);
          return true;
        case NUM_LESSER_EQUAL:
          predicate = builder.le(this.path, Integer.parseInt((String) value));
          this.predicates.add(predicate);
          return true;
        default:
          return false;
      }

    } catch (Exception e) {
      return false;
    }
  }

  @Override
  public Predicate[] getPredicateArray() {
    return this.predicates.toArray(new Predicate[this.predicates.size()]);
  }
}
