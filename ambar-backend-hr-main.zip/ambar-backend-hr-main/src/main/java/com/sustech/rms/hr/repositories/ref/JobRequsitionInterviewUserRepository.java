package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobRequsitionInterviewerUser;
import com.sustech.rms.hr.projection.InterviewUserProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRequsitionInterviewUserRepository extends JpaRepository<JobRequsitionInterviewerUser, Long> {
    List<InterviewUserProjection> findAllByOrderById();
    List<JobRequsitionInterviewerUser> findAllByIdIn(List<Long> ids);
}
