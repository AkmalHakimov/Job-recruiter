package com.sustech.rms.hr.repositories.predicate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.sustech.rms.hr.constants.JobRequisitionEnums.SelectOperatorCode;
import com.sustech.rms.hr.constants.JobRequisitionEnums.StringOperatorCode;

import lombok.Getter;

public class PredicateSetStringImpl implements PredicateSet {

  @Getter
  private String columnCode;

  @Getter
  private Path<String> path;

  @Getter
  private List<Predicate> predicates;

  public PredicateSetStringImpl(String columnCode, Root<?> root, List<String> keys) {
    this.columnCode = columnCode;
    this.predicates = new ArrayList<Predicate>();
    Iterator<String> iterator = keys.iterator();

    while (iterator.hasNext()) {
      String key = iterator.next();
      this.path = this.path == null ? root.get(key) : this.path.get(key);
    }
  }

  private boolean addStringOperatorPredicate(CriteriaBuilder builder, String operatorCode, Object value) {
    Predicate predicate = null;
    String strval = (String) value;
    String strexp = "%@" + strval + "%";
    char escape = '@';

    try {
      switch (StringOperatorCode.valueOf(operatorCode)) {
        case STR_EQUAL:
          predicate = builder.equal(this.path, (String) value);
          this.predicates.add(predicate);
          return true;
        case STR_NOT_EQUAL:
          predicate = builder.notEqual(this.path, (String) value);
          this.predicates.add(predicate);
          return true;
        case STR_CONTAIN:
          predicate = builder.like(this.path, strexp, escape);
          this.predicates.add(predicate);
          return true;
        case STR_NOT_CONTAIN:
          predicate = builder.notLike(this.path, strexp, escape);
          this.predicates.add(predicate);
          return true;
        default:
          return false;
      }
    } catch (Exception e) {
      return false;
    }
  }

  private boolean addSelectOperatorPredicate(CriteriaBuilder builder, String operatorCode, Object value) {
    Predicate predicate = null;

    try {
      switch (SelectOperatorCode.valueOf(operatorCode)) {
        case SEL_EQUAL:
          predicate = builder.equal(this.path, (String) value);
          this.predicates.add(predicate);
          return true;
        case SEL_NOT_EQUAL:
          predicate = builder.notEqual(this.path, (String) value);
          this.predicates.add(predicate);
          return true;
        default:
          return false;
      }
    } catch (Exception e) {
      return false;
    }
  }

  @Override
  public boolean addPredicate(CriteriaBuilder builder, String operatorCode, Object value) {
    return addStringOperatorPredicate(builder, operatorCode, value)
        || addSelectOperatorPredicate(builder, operatorCode, value);
  }

  @Override
  public Predicate[] getPredicateArray() {
    return this.predicates.toArray(new Predicate[this.predicates.size()]);
  }

}
