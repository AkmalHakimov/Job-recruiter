package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobExperienceSpecEntity;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.projection.JobExProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface JobExpSpecRepository extends JpaRepository<JobExperienceSpecEntity, Long> {

    Page<JobExProjection> findAllByJobPositionId(Long positionId, Pageable pageable);

    List<JobExperienceSpecEntity> findAllByJobPosition(JobPositionEntity jobPosition);

    Optional<JobExProjection> getFirstByJobPositionId(Long positionId);
}
