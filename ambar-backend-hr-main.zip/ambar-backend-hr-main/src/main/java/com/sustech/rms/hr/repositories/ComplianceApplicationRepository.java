package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.Compliance;
import com.sustech.rms.hr.entities.ComplianceApplication;
import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.projection.CustomComplianceApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ComplianceApplicationRepository extends JpaRepository<ComplianceApplication, Long> {
    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);

    @Transactional
    @Modifying
    void deleteAllByComplianceId(Long id);

    @Transactional
    @Modifying
    void deleteAllByCertificationId(Long id);

    @Transactional
    @Modifying
    void deleteAllByQualificationId(Long id);

    List<CustomComplianceApplication> findAllByApplicationId(Long id);
    List<ComplianceApplication> findAllByApplication(Application application);
    ComplianceApplication findByComplianceAndApplication(Compliance compliance, Application application);

    Integer countAllByApplication_RequisitionAndStatusNot(JobPositionEntity jobPosition, String status);
    Integer countAllByApplication_RequisitionAndStatus(JobPositionEntity jobPosition, String status);
    Integer countAllByApplication_Requisition(JobPositionEntity jobPosition);
}
