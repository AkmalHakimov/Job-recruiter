package com.sustech.rms.hr.repositories.page;

import lombok.Getter;

@Getter
public class RequestPageImpl implements RequestPage {

  private int pageNumber;

  private int pageLimit;

  private int startingIndex;

  public RequestPageImpl(int pageNumber, int pageLimit) {
    this.pageNumber = pageNumber;
    this.pageLimit = pageLimit;
    this.startingIndex = (pageNumber - 1) * pageLimit;
  }

}
