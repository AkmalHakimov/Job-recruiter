package com.sustech.rms.hr.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class ApplicantDetailsDto {
    private String name;
    private String email;
    private Boolean active;
}
