package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.ResumeReport;
import com.sustech.rms.hr.projection.CustomResumeReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ResumeReportRepository extends JpaRepository<ResumeReport, Long> {
    List<ResumeReport> findAllByApplicationAndOccurrencesGreaterThan(Application application,Integer occurences);
    List<CustomResumeReport> findAllByApplicationId(Long applicationId);
    @Transactional
    @Modifying
    void deleteAllByApplicationId(Long applicationId);

    @Transactional
    @Modifying
    void deleteAllBySkillId(Long skillId);
}
