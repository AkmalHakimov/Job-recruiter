package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobRequsitionTemplate;
import com.sustech.rms.hr.projection.JobReqTemProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRequisitionTemplateRepository extends JpaRepository<JobRequsitionTemplate, Long> {
    List<JobReqTemProjection> findAllByOrderById();
}
