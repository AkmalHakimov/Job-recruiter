package com.sustech.rms.hr.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ProgressSummaryRes {
    private String requisitionStatus;
    private String approvalStatus;
    private String interviewerStatus;
    private Integer openJobPostings;
    private Integer shortlistedCandidates;
    private Integer newApplicantsForReview;
    private Integer scheduledInterviews;
    private Integer unscheduledInterviews;
    private Integer interviewsPendingFeedback;
    private Integer incompleteCompliance;
    private Integer candidatesWaitingToOnboard;
}
