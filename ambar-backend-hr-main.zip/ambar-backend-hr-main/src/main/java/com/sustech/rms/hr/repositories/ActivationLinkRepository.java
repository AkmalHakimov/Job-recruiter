package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.ActivationLink;
import com.sustech.rms.hr.entities.Applicant;
import com.sustech.rms.hr.entities.Application;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ActivationLinkRepository extends JpaRepository<ActivationLink, Long> {
    Optional<ActivationLink> findByApplication(Application application);
    Optional<ActivationLink> findByApplicationAndActiveIsTrue(Application application);

    Optional<ActivationLink> findByCode(String code);
    Optional<ActivationLink> findByCodeAndPassword(String code,String password);

    Optional<ActivationLink> findByCodeAndPasswordAndActiveIsFalse(String code, String password);
    Optional<ActivationLink> findByApplicationAndPassword(Application application, String password);
}
