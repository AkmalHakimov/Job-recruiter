package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.Application;
import com.sustech.rms.hr.entities.QualificationReview;
import com.sustech.rms.hr.projection.CustomQualificationReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface QualificationReviewRepository extends JpaRepository<QualificationReview, Long> {
    List<QualificationReview> findAllByApplication(Application application);

    List<CustomQualificationReview> findAllByApplicationId(Long applicationId);

    @Transactional
    @Modifying
    void deleteAllByApplication(Application application);

    @Transactional
    @Modifying
    void deleteAllByQualificationId(Long id);
}
