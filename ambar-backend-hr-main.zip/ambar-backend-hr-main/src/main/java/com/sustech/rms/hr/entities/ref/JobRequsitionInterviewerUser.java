package com.sustech.rms.hr.entities.ref;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hgz_job_req_intw_user")
public class JobRequsitionInterviewerUser extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRS_REF_INTW_PK_ID")
    private Long id;

    @Column(name = "PRS_REF_INTW_USER_NAME")
    private String fullName;

    @Column(unique = true, name = "PRS_REF_REQ_INTW_USR_EML")
    private String email;

    public JobRequsitionInterviewerUser(String fullName, String email) {
        this.fullName = fullName;
        this.email = email;
    }
}
