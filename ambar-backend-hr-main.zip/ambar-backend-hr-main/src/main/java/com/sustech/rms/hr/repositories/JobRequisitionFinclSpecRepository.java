package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobRequisitionFinclSpecEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRequisitionFinclSpecRepository extends JpaRepository<JobRequisitionFinclSpecEntity, Long> {
    JobRequisitionFinclSpecEntity findByJobPositionId(Long jobPositionId);
}
