package com.sustech.rms.hr.dto.request;

import java.util.List;

import org.springframework.lang.Nullable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JobRequisitionsRequest {

  @Nullable
  private String simpleSearchValue;

  @Nullable
  private List<SearchCriteriaRequest> advancedSearchCriteria;

  @Nullable
  private Integer page;

}
