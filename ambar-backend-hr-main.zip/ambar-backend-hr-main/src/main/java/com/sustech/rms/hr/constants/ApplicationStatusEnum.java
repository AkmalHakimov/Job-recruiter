package com.sustech.rms.hr.constants;

public enum ApplicationStatusEnum {
    NEW_APPLICATION,
    SHORTLISTED,
    INTERVIEW_SCHEDULED,
    INTERVIEW_IN_REVIEW,
    SELECTED,
    COMPLIANCE_CHECKS,
    ONBOARDING,
    ONBOARDED,
    REJECTED
}
