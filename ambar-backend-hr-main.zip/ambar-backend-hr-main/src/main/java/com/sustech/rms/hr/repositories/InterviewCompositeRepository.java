package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.dto.request.SearchCriteriaRequest;
import com.sustech.rms.hr.entities.Interview;
import com.sustech.rms.hr.repositories.page.RequestPage;
import com.sustech.rms.hr.repositories.page.ResponsePage;

import java.util.List;

public interface InterviewCompositeRepository {
    ResponsePage<Interview> findInterview(Long requisitionId, String searchValue, RequestPage requestPage);

    ResponsePage<Interview> findInterview(Long requisitionId, List<SearchCriteriaRequest> criteria, RequestPage requestPage);
}
