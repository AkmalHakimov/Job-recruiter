package com.sustech.rms.hr.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JobExpRequest {
    @NotNull
    private Long positionId;
    @NotNull
    private Long industryId;
    @NotNull
    private Long industryDisciplineId;
    @NotNull
    private Long jobPositionTypeId;
    @NotNull
    private Boolean mandatory;
    @NotNull
    private float weight;
    private String note;

}
