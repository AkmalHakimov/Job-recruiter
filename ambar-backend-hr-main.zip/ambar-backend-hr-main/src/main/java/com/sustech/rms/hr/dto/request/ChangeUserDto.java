package com.sustech.rms.hr.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class ChangeUserDto {

    private List<Long> userList;

    private Long positionId;

    private Long stepId;


}
