package com.sustech.rms.hr.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class RequisitionsByCriteriaRequest {
    private String columns;
    private String operators;
    private String values;
    private Integer page;
    private Integer pageLimit;
}
