package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class JobLocationSpecRequest {
    @NotNull
    private Long positionId;
    @NotNull
    private Long cityId;
    @NotNull
    private Float weight;
    @NotNull
    private Float distance;
    @NotNull
    private Boolean mandatory;
    @NotNull
    private Boolean remote;
    private String note;
}
