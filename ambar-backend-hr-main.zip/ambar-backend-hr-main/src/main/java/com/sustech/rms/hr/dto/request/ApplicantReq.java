package com.sustech.rms.hr.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicantReq {
    @NotNull
    private String firstName;
    @NotNull
    private String middleName;
    @NotNull
    private String surName;
    @NotNull
    private String title;
    @NotNull
    @Email
    private String email;
    @NotNull
    private String mobile;
    @NotNull
    private String phone;
    @NotNull
    private Byte totalExperience;
    @NotNull
    private Long currentSalary;
    @NotNull
    private Long expectedSalary;
}
