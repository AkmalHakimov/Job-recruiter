package com.sustech.rms.hr.repositories.ref;

import org.springframework.data.repository.CrudRepository;

import com.sustech.rms.hr.entities.ref.OrgDepartmentRefEntity;

public interface OrgDepartmentRefRepository extends CrudRepository<OrgDepartmentRefEntity, Long> {

}
