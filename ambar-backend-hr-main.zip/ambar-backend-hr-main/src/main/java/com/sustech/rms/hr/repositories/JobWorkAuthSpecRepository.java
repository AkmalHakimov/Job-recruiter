package com.sustech.rms.hr.repositories;

import com.sustech.rms.hr.entities.JobPositionEntity;
import com.sustech.rms.hr.entities.JobReqWorkAuthSpecEntity;
import com.sustech.rms.hr.projection.JobWorkAuthSpecProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface JobWorkAuthSpecRepository extends JpaRepository<JobReqWorkAuthSpecEntity, Long> {
    Page<JobWorkAuthSpecProjection> findAllByJobPositionId(Long positionId, Pageable pageable);

    List<JobReqWorkAuthSpecEntity> findAllByJobPosition(JobPositionEntity jobPosition);

    Optional<JobWorkAuthSpecProjection> getFirstByJobPositionId(Long positionId);
}
