package com.sustech.rms.hr.repositories.ref;

import com.sustech.rms.hr.entities.ref.JobRoleRespRefEntity;
import com.sustech.rms.hr.projection.JobQualProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRoleRespRefRepository extends JpaRepository<JobRoleRespRefEntity,Long> {
    List<JobQualProjection> findAllByJobDesignationTypeIdOrderById(Long id);

}
