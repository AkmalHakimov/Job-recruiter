package com.sustech.rms.hr.entities.ref;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "hgz_job_role_resp_ref")
public class JobRoleRespRefEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "N_JOB_ROLE_RESP_REF_PK_ID")
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "N_JOB_DESGNTN_TYP_REF_PK_ID")
  private JobDesignationTypeRefEntity jobDesignationType;

  @Column(name = "V_JOB_ROLE_RESP_CD")
  private String code;

  @Column(name = "V_JOB_ROLE_RESP_DESC")
  private String description;

  @Column(name = "V_PRTY_ORG_SRCE_SYS_CD")
  private String systemCode;

  public JobRoleRespRefEntity(JobDesignationTypeRefEntity jobDesignationType, String code, String description) {
    this.jobDesignationType = jobDesignationType;
    this.code = code;
    this.description = description;
  }
}
