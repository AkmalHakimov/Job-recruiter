package com.sustech.rms.hr.projection;

import com.sustech.rms.hr.constants.ContractTypeEnum;
import com.sustech.rms.hr.entities.EmployeeOnboardingDocument;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import java.util.Optional;

public interface CustomContractApplication {
    Long getId();
    @Value("#{target.applicant.id}")
    Long getApplicantId();
    @Value("#{target.applicant.firstName}")
    String getApplicantName();
    @Value("#{target.applicant.email}")
    String getApplicantEmail();
    @Value("#{target.applicant.phone}")
    String getApplicantPhone();
    @Value("#{target.requisition.orgDepartment.name}")
    String getDepartment();
    @Value("#{target.requisition.jobPositionType.description}")
    String getJobTitle();
    @Value("#{target.requisition.city.name}")
    String getCity();
    @Value("#{target.requisition.city.country.name}")
    String getCountry();
    @Value("#{@jobRequisitionSummaryRepository.findByRequisitionIdOrderByIdAsc(target.requisition.id)}")
    Optional<JobRequisitionSummaryProjection> getRequisitionSummary();
    @Value("#{@jobRequisitionFinclSpecRepository.findByJobPositionId(target.requisition.id)?.jobReqApplTypeRef?.description}")
    ContractTypeEnum getContractType();
    @Value("#{@contractLetterRepository.findByApplicationId(target.id).orElse(null)?.employeeOnboardingDocuments}")
    List<EmployeeOnboardingDocument> getEmployeeOnboardingDocuments();
    @Value("#{@contractLetterRepository.findByApplicationId(target.id)}")
    Optional<ContractLetterProjection> getContractLetter();
}
