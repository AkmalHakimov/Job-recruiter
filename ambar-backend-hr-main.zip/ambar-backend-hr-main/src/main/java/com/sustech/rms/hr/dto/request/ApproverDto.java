package com.sustech.rms.hr.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class ApproverDto {

    @NotNull
    private Long positionId;

    @NotNull
    private String fullName;

    @NotNull
    private String email;

    @NotEmpty
    private List<Long> departmentIds;

    @NotEmpty
    private List<Long> designationIds;

}
