package com.sustech.rms.hr.projection;

import org.springframework.beans.factory.annotation.Value;

public interface JobLocationProjection {
    Long getId();
    @Value("#{target.city.id}")
    Long getCityId();
    @Value("#{target.city.country.id}")
    Long getCountryId();
    Float getWeight();
    Float getDistance();
    Boolean getMandatory();
    Boolean getRemote();
    String getNote();
}
