package com.sustech.rms.hr.entities;

import com.sustech.rms.hr.entities.template.AbstractEntity;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "hgz_employee_onboarding_document")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeOnboardingDocument extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hgz_employee_onboarding_document_pk_id")
    private Long id;
    private String originalName;
    private String fileFormat;
    private String fileName;
    private LocalDate reminderDate;
    private String source;
    private String notes;
}
