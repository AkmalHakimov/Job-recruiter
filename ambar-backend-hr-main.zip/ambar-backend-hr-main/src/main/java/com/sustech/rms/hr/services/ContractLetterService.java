package com.sustech.rms.hr.services;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import com.sustech.rms.hr.constants.EmailTemplateTypeEnum;
import com.sustech.rms.hr.dto.request.ContractLetterDto;
import com.sustech.rms.hr.dto.request.ContractLetterOnboardingDocumentDto;
import com.sustech.rms.hr.dto.request.UploadComplianceDto;
import com.sustech.rms.hr.dto.request.UploadDocDto;
import com.sustech.rms.hr.dto.response.ApiResponse;
import com.sustech.rms.hr.entities.*;
import com.sustech.rms.hr.projection.CustomComplianceApplication;
import com.sustech.rms.hr.projection.JobRequisitionSummaryProjection;
import com.sustech.rms.hr.repositories.*;
import com.sustech.rms.hr.repositories.ref.ApplTypeRefRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

import com.itextpdf.text.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static com.sustech.rms.hr.services.PDFEditor.replaceText;

@Service
@RequiredArgsConstructor
@Slf4j
public class ContractLetterService {
    private final AttachmentRepository attachmentRepository;
    private final ApplicationRepository applicationRepository;
    private final ContractLetterRepository contractLetterRepository;
    private final FileLoader fileLoader;
    private final JobRequisitionSummaryRepository jobRequisitionSummaryRepository;
    @Value("${domain.url}")
    private String domainUrl;
    private final ActivationLinkRepository activationLinkRepository;
    private final EmailSenderService emailSenderService;
    private final ComplianceApplicationRepository complianceApplicationRepository;
    private final ComplianceRepository complianceRepository;
    private final ResourceLoader resourceLoader;
    private final ApplTypeRefRepository applTypeRefRepository;
    private final EmployeeOnboardingDocumentRepository employeeOnboardingDocumentRepository;
    private final EmailTemplateRepository emailTemplateRepository;
    private final JobRequisitionFinclSpecRepository jobRequisitionFinclSpecRepository;
    @Value("${UPLOAD_DIR}")
    private String UPLOAD_DIR;

    public ApiResponse getApplicationDetails(Long applicationId) {
        return ApiResponse.builder()
                .success(true)
                .data(applicationRepository.findByIdOrderByIdDesc(applicationId))
                .build();
    }

    public ApiResponse saveContractLetter(ContractLetterDto contractLetterDto) {
        Application application = applicationRepository.getReferenceById(contractLetterDto.getApplicationId());
        Optional<ContractLetter> contractLetterOptional = contractLetterRepository.findByApplication(application);
        ContractLetter contractLetter;
//        System.out.println(applTypeRefRepository.findByDescription(contractLetterDto.getContractType()).orElseThrow().getDescription());
        if (contractLetterOptional.isPresent()) {
            contractLetter = contractLetterOptional.get();
            contractLetter.setContractType(jobRequisitionFinclSpecRepository.findByJobPositionId(application.getRequisition().getId()).getJobReqApplTypeRef());
            contractLetter.setContractCommencementDate(contractLetter.getContractCommencementDate());
            contractLetter.setPay(contractLetterDto.getPay());
            contractLetter.setLocation(contractLetterDto.getLocation());
            contractLetter.setGoverningLaw(contractLetterDto.getGoverningLaw());
            contractLetter.setHoursOfOperation(contractLetterDto.getHoursOfOperation());
            contractLetter.setIndustrialInstrument(contractLetterDto.getIndustrialInstrument());
            contractLetter.setServices(contractLetterDto.getServices());
            contractLetter.setDateOfAgreement(contractLetterDto.getDateOfAgreement());
            contractLetter.setNoticePeriod(contractLetterDto.getNoticePeriod());
            contractLetter.setName(contractLetterDto.getName());
            contractLetter.setNumberOfDays(contractLetterDto.getNumberOfDays());
            contractLetter.setLiabilityRequirement(contractLetterDto.getLiabilityRequirement());
            contractLetter.setEmployeeOnboardingDocuments(contractLetterDto.getEmployeeOnboardingDocuments());
            contractLetter.setFee(contractLetterDto.getFee());
        } else {
            contractLetter = ContractLetter.builder()
                    .application(application)
                    .contractType(jobRequisitionFinclSpecRepository.findByJobPositionId(application.getRequisition().getId()).getJobReqApplTypeRef())
                    .contractCommencementDate(contractLetterDto.getContractCommencementDate())
                    .pay(contractLetterDto.getPay())
                    .location(contractLetterDto.getLocation())
                    .governingLaw(contractLetterDto.getGoverningLaw())
                    .hoursOfOperation(contractLetterDto.getHoursOfOperation())
                    .industrialInstrument(contractLetterDto.getIndustrialInstrument())
                    .services(contractLetterDto.getServices())
                    .dateOfAgreement(contractLetterDto.getDateOfAgreement())
                    .noticePeriod(contractLetterDto.getNoticePeriod())
                    .name(contractLetterDto.getName())
                    .numberOfDays(contractLetterDto.getNumberOfDays())
                    .liabilityRequirement(contractLetterDto.getLiabilityRequirement())
                    .fee(contractLetterDto.getFee())
                    .employeeOnboardingDocuments(contractLetterDto.getEmployeeOnboardingDocuments() != null ? contractLetterDto.getEmployeeOnboardingDocuments() : null)
                    .build();
        }
        contractLetterRepository.save(contractLetter);
        return ApiResponse.builder()
                .success(true)
                .message("saved")
                .data(contractLetter.getId())
                .build();
    }

    public ResponseEntity<byte[]> preview(Long contractId) throws DocumentException, IOException {
        ByteArrayResource resource = new ByteArrayResource(generatePdfFile(contractId));
        return ResponseEntity.ok(resource.getByteArray());

    }

    public byte[] generatePdfFile(Long id) throws DocumentException, IOException {
        ContractLetter contractLetter = contractLetterRepository.getReferenceById(id);
        Optional<ActivationLink> activationLinkOptional = activationLinkRepository.findByApplication(contractLetter.getApplication());
        ActivationLink activationLink = activationLinkOptional.orElseGet(() -> createActivationLink(contractLetter));
        List<CustomComplianceApplication> list = complianceApplicationRepository.findAllByApplicationId(contractLetter.getApplication().getId());
        Optional<JobRequisitionSummaryProjection> jobRequisitionSummaryOptional = jobRequisitionSummaryRepository.findByRequisitionIdOrderByIdAsc(contractLetter.getApplication().getRequisition().getId());

        PDDocument document = null;
        Resource resource = resourceLoader.getResource("classpath:" + contractLetter.getContractType().getDescription() + ".pdf");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        document = PDDocument.load(resource.getInputStream());
        document = replaceText(document, "SAPPLICANTNAMES", contractLetter.getApplication().getApplicant().getFirstName() + " " + contractLetter.getApplication().getApplicant().getMiddleName() + " " + contractLetter.getApplication().getApplicant().getSurName());
        document = replaceText(document, "SLIABILITYS", contractLetter.getLiabilityRequirement());
        document = replaceText(document, "SNOTICEPERIODS", contractLetter.getNoticePeriod());
        document = replaceText(document, "SJOBPOSITIONS", contractLetter.getApplication().getRequisition().getJobPositionType().getDescription());
        document = replaceText(document, "SLOCATIONCOUNTRYS", contractLetter.getApplication().getRequisition().getCity().getName() + ", " + contractLetter.getApplication().getRequisition().getCity().getCountry().getName());
        document = replaceText(document, "SPAYS", contractLetter.getPay());
        document = replaceText(document, "SINDINSTRUMENTS", contractLetter.getIndustrialInstrument());
        document = replaceText(document, "SCOMMENCEMENTDATES", contractLetter.getContractCommencementDate().toString());
        document = replaceText(document, "SFEES", contractLetter.getFee() == null ? "null" : contractLetter.getFee());
        document = replaceText(document, "SSERVICESS", contractLetter.getServices());
        document = replaceText(document, "SNOTICEPERIODS", contractLetter.getNoticePeriod());
        document = replaceText(document, "SNUMBEROFDAYS", String.valueOf(contractLetter.getNumberOfDays()));
        document = replaceText(document, "SDATES", LocalDate.now().toString());
        System.out.println(list.size());
        document = replaceText(document, "SDETAILONES", !list.isEmpty() ? checkCertification(list.get(0)) : "Empty");
        document = replaceText(document, "SDETAILTWOS", list.size() > 1 ? checkCertification(list.get(1)) : "Empty");
        document = replaceText(document, "SDETAILTHREES", list.size() > 2 ? checkCertification(list.get(2)) : "Empty");
        document = replaceText(document, "<PWD>", activationLink.getPassword());
        if (jobRequisitionSummaryOptional.isPresent()) {
            document = replaceText(document, "<HiringManagerName>", jobRequisitionSummaryOptional.get().getHiringManager());
        }
        document.save(out);
        document.close();
        return out.toByteArray();
    }

    private String checkCertification(CustomComplianceApplication customComplianceApplication) {
        if (customComplianceApplication.getQualification() != null) {
            return customComplianceApplication.getQualification().getNotes();
        } else if (customComplianceApplication.getCompliance() != null) {
            return customComplianceApplication.getCompliance().getNotes();
        } else if (customComplianceApplication.getCertification() != null) {
            return customComplianceApplication.getCertification().getNotes();
        } else {
            return "Empty";
        }
    }

    public ResponseEntity<ByteArrayResource> downloadContractLetter(Long applicationId) throws DocumentException, IOException {
        System.out.println(applicationId);
        System.out.println(applicationRepository.getReferenceById(applicationId).getId());
        ContractLetter contractLetter = contractLetterRepository.findByApplication(applicationRepository.getReferenceById(applicationId))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "application not found"));
        ByteArrayResource resource = new ByteArrayResource(generatePdfFile(contractLetter.getId()));
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .contentLength(resource.contentLength())
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment()
                                .filename("contractLetter.pdf")
                                .build().toString())
                .body(resource);
    }


    public ResponseEntity<byte[]> viewContractLetter(Long applicationId) throws DocumentException, IOException {
        ContractLetter contractLetter = contractLetterRepository.findByApplication(applicationRepository.getReferenceById(applicationId)).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "application not found"));
        ByteArrayResource resource = new ByteArrayResource(generatePdfFile(contractLetter.getId()));
        return ResponseEntity.ok(resource.getByteArray());
    }

    public ApiResponse send(Long contractId) throws IOException, DocumentException {
        String contractTxt = generateContractText(contractId, "\n");
        ContractLetter contractLetter = contractLetterRepository.getReferenceById(contractId);
        Applicant applicant = contractLetter.getApplication().getApplicant();
        Map<String, byte[]> files = new HashMap<>();
        files.put("contractLetter.pdf", generatePdfFile(contractId));
        boolean emailSendResult = emailSenderService.sendEmailWithFile(applicant.getEmail(), emailTemplateRepository.findByEmailType(EmailTemplateTypeEnum.CONTRACT_OFFER_NOTIFICATION).orElseThrow().getEmailSubject(), contractTxt, files);
        if (emailSendResult) {
            contractLetter.setSent(true);
            contractLetterRepository.save(contractLetter);
        }
        return ApiResponse.builder()
                .success(emailSendResult)
                .build();
    }

    private String generateContractLetter(Long contractId, String breakSymbol) {
        ContractLetter contractLetter = contractLetterRepository.getReferenceById(contractId);
        String contractTxt = "";
        try {
            Optional<ActivationLink> activationLinkOptional = activationLinkRepository.findByApplication(contractLetter.getApplication());
            ActivationLink activationLink = activationLinkOptional.orElseGet(() -> createActivationLink(contractLetter));
            Optional<JobRequisitionSummaryProjection> jobRequisitionSummaryOptional = jobRequisitionSummaryRepository.findByRequisitionIdOrderByIdAsc(contractLetter.getApplication().getRequisition().getId());
            contractTxt = fileLoader.readWordFileFromResources(contractLetter.getContractType().getDescription() + ".docx", breakSymbol);
            contractTxt = contractTxt.replaceAll("<ApplicantName>", contractLetter.getApplication().getApplicant().getFirstName())
                    .replaceAll("<JobPosition>", contractLetter.getApplication().getRequisition().getJobPositionType().getDescription())
                    .replaceAll("<Location,Country>", contractLetter.getApplication().getRequisition().getCity().getName() + ", " + contractLetter.getApplication().getRequisition().getCity().getCountry().getName())
                    .replaceAll("<ContractCommencementDate>", contractLetter.getContractCommencementDate().toString())
                    .replaceAll("<HoursOfOperation>", contractLetter.getHoursOfOperation().toString())
                    .replaceAll("<ApplicantEmail>", contractLetter.getApplication().getApplicant().getEmail())
                    .replaceAll("<Pay>", contractLetter.getPay())
                    .replaceAll("<Date>", LocalDate.now().toString())
                    .replaceAll("<IndustrialInstrument>", contractLetter.getIndustrialInstrument())
                    .replace("<PWD>", activationLink.getPassword());
            System.out.println("hello");
            if (jobRequisitionSummaryOptional.isPresent()) {
                contractTxt = contractTxt.replaceAll("<HiringManagerName>", jobRequisitionSummaryOptional.get().getHiringManager());
            }
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
        return contractTxt;
    }

    private String generateContractText(Long contractId, String breakSymbol) {
        ContractLetter contractLetter = contractLetterRepository.getReferenceById(contractId);
        String contractTxt = "";
        Optional<ActivationLink> activationLinkOptional = activationLinkRepository.findByApplication(contractLetter.getApplication());
        ActivationLink activationLink = activationLinkOptional.orElseGet(() -> createActivationLink(contractLetter));
        Optional<JobRequisitionSummaryProjection> jobRequisitionSummaryOptional = jobRequisitionSummaryRepository.findByRequisitionIdOrderByIdAsc(contractLetter.getApplication().getRequisition().getId());
        contractTxt = emailTemplateRepository.findByEmailType(EmailTemplateTypeEnum.CONTRACT_OFFER_NOTIFICATION).orElseThrow().getEmailBody();
        contractTxt = contractTxt.replaceAll("<ApplicantName>", contractLetter.getApplication().getApplicant().getFirstName())
                .replaceAll("<JobPosition>", contractLetter.getApplication().getRequisition().getJobPositionType().getDescription())
                .replaceAll("<Location,Country>", contractLetter.getApplication().getRequisition().getCity().getName() + ", " + contractLetter.getApplication().getRequisition().getCity().getCountry().getName())
                .replaceAll("<CommencementDate>", contractLetter.getContractCommencementDate().toString())
                .replaceAll("<Link>", domainUrl + "/contract-letter/" + contractId)
                .replace("<PWD>", activationLink.getPassword());

//            if (jobRequisitionSummaryOptional.isPresent()) {
//                contractTxt = contractTxt.replaceAll("<HiringManagerName>", jobRequisitionSummaryOptional.get().getHiringManager());
//            }
        System.out.println(contractTxt);
        return contractTxt;
    }

    private ActivationLink createActivationLink(ContractLetter contractLetter) {
        String password = PasswordGenerator.generateRandomPassword(6);
        ActivationLink activationLink = ActivationLink.builder()
                .application(contractLetter.getApplication())
                .password(password)
                .build();
        activationLinkRepository.save(activationLink);
        return activationLink;
    }

    public ApiResponse complianceDocs(Long contractId) {
        ContractLetter contractLetter = contractLetterRepository.getReferenceById(contractId);
        Application application = contractLetter.getApplication();
//        Applicant applicant = contractLetter.getApplication().getApplicant();
//        activationLinkRepository.findByApplicationAndActiveIsTrue(contractLetter.getApplication()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not active"));
//        List<CustomComplianceApplication> complianceApplications = complianceApplicationRepository.findAllByApplicationId(contractLetter.getApplication().getId());
        ComplianceApplication signedcontractletteronlyforonlyapp = complianceApplicationRepository.findByComplianceAndApplication(complianceRepository.findByJobPositionEntityIdAndNotes(application.getRequisition().getId(), "signedcontractletteronlyforonlyapp"), application);
        List<ComplianceApplication> complianceApplications = List.of(signedcontractletteronlyforonlyapp);
        return ApiResponse.builder()
                .data(complianceApplications)
                .build();
    }

    @Transactional
    public ApiResponse uploadCompliance(UploadComplianceDto dto) {
        for (UploadDocDto doc : dto.getDocs()) {
            var complianceApplication = complianceApplicationRepository.getReferenceById(doc.getComplianceId());
            complianceApplication.setApplicantFile(attachmentRepository.getReferenceById(doc.getFileId()));
            complianceApplicationRepository.save(complianceApplication);
        }
        return ApiResponse.builder().build();
    }

    public ApiResponse getApplicationDetailsByContractLetter(Long contractId) {
        return getApplicationDetails(contractLetterRepository.getReferenceById(contractId).getApplication().getId());
    }
}
