package com.sustech.rms.hr.projection;

import java.time.LocalDate;

public interface OfferLetterProjection {
    Long getId();
    LocalDate getOfferCreationDate();
    LocalDate getOfferAcceptanceDate();
    LocalDate getOfferDueDate();
    LocalDate getDateOfJoining();
    String getPayFrequency();
    String getSalaryType();
    String getSalaryWageRate();
    String getCurrencyType();
    Boolean getSent();
}
