# hgz-recruitement-svc-HR

### Welcome to the Hourglaz Recruitment domain backend project!

Further instructions will be added here soon!
